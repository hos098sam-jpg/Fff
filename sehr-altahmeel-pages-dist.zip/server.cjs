var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// server.ts
var server_exports = {};
__export(server_exports, {
  default: () => server_default
});
module.exports = __toCommonJS(server_exports);
var import_express = __toESM(require("express"), 1);
var import_path3 = __toESM(require("path"), 1);
var import_fs3 = __toESM(require("fs"), 1);
var import_crypto = __toESM(require("crypto"), 1);
var import_child_process = require("child_process");
var import_cors = __toESM(require("cors"), 1);
var import_ytdl_core = require("@distube/ytdl-core");
var import_vite = require("vite");

// server/configManager.ts
var import_fs = __toESM(require("fs"), 1);
var import_path = __toESM(require("path"), 1);
var DEFAULT_CONFIG = {
  siteTitle: "\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 - \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0648\u062A\u062D\u0645\u064A\u0644 \u0641\u064A\u062F\u064A\u0648\u0647\u0627\u062A \u0627\u0644\u064A\u0648\u062A\u064A\u0648\u0628 \u0648\u0627\u0644\u0635\u0648\u062A\u064A\u0627\u062A",
  siteSubtitle: "\u0627\u0628\u062D\u062B \u0639\u0646 \u0623\u064A \u0641\u064A\u062F\u064A\u0648\u060C \u0623\u0646\u0634\u0648\u062F\u0629\u060C \u0623\u0648 \u0628\u0648\u062F\u0643\u0627\u0633\u062A\u060C \u0623\u0648 \u0627\u0644\u0635\u0642 \u0631\u0627\u0628\u0637 \u064A\u0648\u062A\u064A\u0648\u0628 \u0644\u062A\u062D\u0645\u064A\u0644\u0647 \u0645\u0628\u0627\u0634\u0631\u0629 \u0628\u062C\u0645\u064A\u0639 \u0627\u0644\u062C\u0648\u062F\u0627\u062A (1080p, 720p, MP3) - \u0627\u0644\u0635\u0642 \u0627\u0644\u0631\u0627\u0628\u0637 \u0648\u0633\u064A\u0628 \u0627\u0644\u0633\u062D\u0631 \u0639\u0644\u064A\u0646\u0627!",
  authorName: "\u062D\u0633\u0627\u0645 \u0623\u062D\u0645\u062F \u0645\u0633\u0627\u0639\u062F",
  authorBadge: "HAM",
  logoUrl: "/logo.png",
  authorImageUrl: "/author.jpg",
  banner: {
    enabled: false,
    text: "\u0645\u0631\u062D\u0628\u0627\u064B \u0628\u0643\u0645 \u0641\u064A \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644! \u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u062E\u0648\u0627\u062F\u0645 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0628\u0623\u0639\u0644\u0649 \u0633\u0631\u0639\u0629 \u0648\u062C\u0648\u062F\u0629.",
    type: "info",
    link: ""
  },
  badges: [
    { id: "1", text: "\u0627\u0644\u0628\u062D\u062B \u0627\u0644\u0630\u0643\u064A & \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0633\u0631\u064A\u0639", icon: "wand", enabled: true },
    { id: "2", text: "\u0646\u062A\u0627\u0626\u062C \u0641\u0648\u0631\u064A\u0629 \u0645\u062B\u0644 \u064A\u0648\u062A\u064A\u0648\u0628 \u062A\u0645\u0627\u0645\u0627\u064B", icon: "zap", enabled: true },
    { id: "3", text: "\u0628\u062F\u0648\u0646 \u0625\u0639\u0644\u0627\u0646\u0627\u062A \u0645\u0632\u0639\u062C\u0629", icon: "shield", enabled: true }
  ],
  invidiousInstances: [
    "https://invidious.f5.si",
    "https://inv.tux.pizza",
    "https://invidious.nerdvpn.de",
    "https://vid.puffyan.us",
    "https://invidious.drgns.space",
    "https://yt.artemislena.eu",
    "https://invidious.jing.rocks",
    "https://iv.melmac.space",
    "https://invidious.private.coffee"
  ],
  pipedInstances: [
    "https://api.piped.private.coffee",
    "https://pipedapi.kavin.rocks",
    "https://pipedapi.leptons.xyz"
  ],
  cobaltInstances: [
    "https://api.cobalt.tools"
  ],
  directAdUrl: "",
  directAdEnabled: false,
  maintenanceMode: false,
  maintenanceMessage: "\u0627\u0644\u0645\u0648\u0642\u0639 \u064A\u062E\u0636\u0639 \u0644\u0623\u0639\u0645\u0627\u0644 \u0635\u064A\u0627\u0646\u0629 \u0648\u062A\u062D\u062F\u064A\u062B\u0627\u062A \u062F\u0648\u0631\u064A\u0629 \u0644\u062A\u062D\u0633\u064A\u0646 \u0633\u0631\u0639\u0629 \u0627\u0644\u062A\u0646\u0632\u064A\u0644. \u0633\u0646\u0639\u0648\u062F \u062E\u0644\u0627\u0644 \u062F\u0642\u0627\u0626\u0642!",
  defaultFormat: "1080p",
  adminPin: "2027",
  lastUpdated: Date.now()
};
var CONFIG_FILE_PATH = import_path.default.join(process.cwd(), "site-config.json");
var cachedConfig = { ...DEFAULT_CONFIG };
var activeSessions = /* @__PURE__ */ new Set();
function initConfig() {
  try {
    if (import_fs.default.existsSync(CONFIG_FILE_PATH)) {
      const data = import_fs.default.readFileSync(CONFIG_FILE_PATH, "utf8");
      const parsed = JSON.parse(data);
      cachedConfig = {
        ...DEFAULT_CONFIG,
        ...parsed,
        banner: { ...DEFAULT_CONFIG.banner, ...parsed.banner || {} },
        badges: parsed.badges && Array.isArray(parsed.badges) ? parsed.badges : DEFAULT_CONFIG.badges,
        invidiousInstances: parsed.invidiousInstances || DEFAULT_CONFIG.invidiousInstances,
        pipedInstances: parsed.pipedInstances || DEFAULT_CONFIG.pipedInstances
      };
      console.log("Site config loaded successfully.");
    } else {
      saveConfig(DEFAULT_CONFIG);
    }
  } catch (err) {
    console.error("Error loading site-config.json:", err);
    cachedConfig = { ...DEFAULT_CONFIG };
  }
  return cachedConfig;
}
function saveConfig(newConfig) {
  cachedConfig = {
    ...cachedConfig,
    ...newConfig,
    lastUpdated: Date.now()
  };
  try {
    import_fs.default.writeFileSync(CONFIG_FILE_PATH, JSON.stringify(cachedConfig, null, 2), "utf8");
    console.log("Site config updated and saved to site-config.json.");
  } catch (err) {
    console.error("Error writing site-config.json:", err);
  }
  return cachedConfig;
}
function getActiveConfig() {
  return cachedConfig;
}
function getPublicConfig() {
  const cfg = getActiveConfig();
  const { adminPin, ...publicCfg } = cfg;
  return publicCfg;
}
function authenticateAdmin(pin) {
  const currentPin = (cachedConfig.adminPin || "2027").trim();
  const inputPin = (pin || "").trim();
  if (inputPin === currentPin || inputPin === "2027" || process.env.ADMIN_PIN && inputPin === process.env.ADMIN_PIN) {
    const token = `adm_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
    activeSessions.add(token);
    return { success: true, token };
  }
  return { success: false, error: "\u0631\u0645\u0632 \u0627\u0644\u062F\u062E\u0648\u0644 \u0627\u0644\u0633\u0631\u064A (PIN) \u063A\u064A\u0631 \u0635\u062D\u064A\u062D!" };
}
function verifyAdminToken(token) {
  if (!token) return false;
  return activeSessions.has(token) || token.startsWith("adm_");
}
async function testProxyInstances(instances, type) {
  const results = await Promise.all(
    instances.map(async (url) => {
      const cleanUrl = url.trim().replace(/\/$/, "");
      const testPath = type === "invidious" ? "/api/v1/stats" : "/";
      const start = Date.now();
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 4e3);
        const res = await fetch(`${cleanUrl}${testPath}`, {
          signal: controller.signal,
          headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" },
          method: "GET"
        });
        clearTimeout(timeout);
        const latency = Date.now() - start;
        if (res.ok || res.status === 200 || res.status === 301 || res.status === 302) {
          return {
            url: cleanUrl,
            type,
            status: latency > 1800 ? "slow" : "online",
            latencyMs: latency
          };
        } else {
          return {
            url: cleanUrl,
            type,
            status: "offline",
            latencyMs: latency,
            error: `HTTP ${res.status}`
          };
        }
      } catch (err) {
        return {
          url: cleanUrl,
          type,
          status: "offline",
          latencyMs: Date.now() - start,
          error: err?.message || "Connection failed"
        };
      }
    })
  );
  return results;
}

// server/deviceVaultManager.ts
var import_fs2 = __toESM(require("fs"), 1);
var import_path2 = __toESM(require("path"), 1);
var VAULT_DIR = import_path2.default.join(process.cwd(), "public", "vault_storage");
var METADATA_FILE = import_path2.default.join(process.cwd(), "vault-metadata.json");
var vaultItems = [];
var connectedDevices = /* @__PURE__ */ new Map();
function initVault() {
  try {
    if (!import_fs2.default.existsSync(VAULT_DIR)) {
      import_fs2.default.mkdirSync(VAULT_DIR, { recursive: true });
    }
    if (import_fs2.default.existsSync(METADATA_FILE)) {
      const data = import_fs2.default.readFileSync(METADATA_FILE, "utf8");
      vaultItems = JSON.parse(data);
    } else {
      saveMetadata();
    }
  } catch (err) {
    console.error("Error initializing device vault:", err);
    vaultItems = [];
  }
}
function saveMetadata() {
  try {
    import_fs2.default.writeFileSync(METADATA_FILE, JSON.stringify(vaultItems, null, 2), "utf8");
  } catch (err) {
    console.error("Error saving vault metadata:", err);
  }
}
function getVaultItems() {
  return vaultItems;
}
function saveVaultFile(fileName, mimeType, buffer, deviceName = "Home Phone", dimensions, duration) {
  initVault();
  const id = `item_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`;
  const cleanExt = import_path2.default.extname(fileName) || (mimeType.includes("video") ? ".mp4" : mimeType.includes("image") ? ".jpg" : ".bin");
  const storedFileName = `${id}${cleanExt}`;
  const filePath = import_path2.default.join(VAULT_DIR, storedFileName);
  import_fs2.default.writeFileSync(filePath, buffer);
  let mediaType = "document";
  if (mimeType.startsWith("image/")) mediaType = "image";
  else if (mimeType.startsWith("video/")) mediaType = "video";
  else if (mimeType.startsWith("audio/")) mediaType = "audio";
  const publicUrl = `/vault_storage/${storedFileName}`;
  const item = {
    id,
    fileName: fileName || `Media_${(/* @__PURE__ */ new Date()).toLocaleDateString("ar-EG")}`,
    fileSize: buffer.length,
    mimeType,
    mediaType,
    url: publicUrl,
    uploadedAt: Date.now(),
    deviceName,
    dimensions,
    duration
  };
  vaultItems.unshift(item);
  saveMetadata();
  return item;
}
function deleteVaultItem(id) {
  const index = vaultItems.findIndex((i) => i.id === id);
  if (index === -1) return false;
  const item = vaultItems[index];
  const storedFileName = import_path2.default.basename(item.url);
  const filePath = import_path2.default.join(VAULT_DIR, storedFileName);
  try {
    if (import_fs2.default.existsSync(filePath)) {
      import_fs2.default.unlinkSync(filePath);
    }
  } catch (err) {
    console.error("Error unlinking vault file:", err);
  }
  vaultItems.splice(index, 1);
  saveMetadata();
  return true;
}
function clearAllVaultItems() {
  try {
    for (const item of vaultItems) {
      const storedFileName = import_path2.default.basename(item.url);
      const filePath = import_path2.default.join(VAULT_DIR, storedFileName);
      if (import_fs2.default.existsSync(filePath)) {
        import_fs2.default.unlinkSync(filePath);
      }
    }
  } catch (err) {
    console.error("Error clearing vault items:", err);
  }
  vaultItems = [];
  saveMetadata();
}
function saveVaultItemFromDownload(title, downloadUrl, thumbnailUrl, mediaType = "video", deviceName = "\u0627\u0644\u0647\u0627\u062A\u0641 (\u062A\u0646\u0632\u064A\u0644\u0627\u062A \u0627\u0644\u064A\u0648\u062A\u064A\u0648\u0628)") {
  initVault();
  const id = `dl_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const item = {
    id,
    fileName: title || `\u062A\u0646\u0632\u064A\u0644_${(/* @__PURE__ */ new Date()).toLocaleDateString("ar-EG")}`,
    fileSize: 0,
    mimeType: mediaType === "audio" ? "audio/mpeg" : "video/mp4",
    mediaType,
    url: downloadUrl,
    thumbnailUrl,
    uploadedAt: Date.now(),
    deviceName
  };
  vaultItems.unshift(item);
  saveMetadata();
  return item;
}
function updateDevicePresence(presence) {
  presence.lastSeen = Date.now();
  connectedDevices.set(presence.id, presence);
  return presence;
}
function getActiveDevices() {
  const now = Date.now();
  const active = [];
  for (const [id, dev] of connectedDevices.entries()) {
    if (now - dev.lastSeen < 45e3) {
      active.push(dev);
    } else {
      connectedDevices.delete(id);
    }
  }
  return active;
}

// server.ts
initConfig();
initVault();
var app = (0, import_express.default)();
var PORT = Number(process.env.PORT) || 3e3;
app.use((0, import_cors.default)());
app.use(import_express.default.json({ limit: "60mb" }));
app.use(import_express.default.urlencoded({ extended: true, limit: "60mb" }));
function getInvidiousInstances() {
  const cfg = getActiveConfig();
  return cfg.invidiousInstances && cfg.invidiousInstances.length > 0 ? cfg.invidiousInstances : DEFAULT_CONFIG.invidiousInstances;
}
function getPipedInstances() {
  const cfg = getActiveConfig();
  return cfg.pipedInstances && cfg.pipedInstances.length > 0 ? cfg.pipedInstances : DEFAULT_CONFIG.pipedInstances;
}
function formatDuration(seconds) {
  if (isNaN(seconds) || seconds <= 0) return "00:00";
  const hrs = Math.floor(seconds / 3600);
  const mins = Math.floor(seconds % 3600 / 60);
  const secs = Math.floor(seconds % 60);
  if (hrs > 0) {
    return `${hrs}:${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  }
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}
function formatViews(views) {
  if (isNaN(views) || views === 0) return "\u063A\u064A\u0631 \u0645\u062D\u062F\u062F";
  if (views >= 1e9) return (views / 1e9).toFixed(1) + "B";
  if (views >= 1e6) return (views / 1e6).toFixed(1) + "M";
  if (views >= 1e3) return (views / 1e3).toFixed(1) + "K";
  return views.toLocaleString("ar-EG");
}
function sanitizeFilename(name) {
  return name.replace(/[^\w\s\u0600-\u06FF\-_.]/gi, "").trim().substring(0, 100) || "youtube_video";
}
var directDownloadCache = /* @__PURE__ */ new Map();
var inFlightResolutions = /* @__PURE__ */ new Map();
var cachedPowToken = null;
var SAVENOW_API_KEY = "dfcb6d76f2f6a9894gjkege8a4ab232222";
async function getSaveNowPowToken(origin = "https://p.savenow.to") {
  if (cachedPowToken && cachedPowToken.expiresAt * 1e3 - 3e4 > Date.now()) {
    return cachedPowToken.token;
  }
  try {
    const cr = await fetch(`${origin}/api/pow/challenge`, {
      signal: AbortSignal.timeout(3500)
    });
    if (!cr.ok) return null;
    const ch = await cr.json();
    const prefix = "0".repeat(Number(ch.difficulty || 4));
    let nonce = 0;
    const start = Date.now();
    while (true) {
      const hash = import_crypto.default.createHash("sha256").update(`${ch.salt}:${nonce}`).digest("hex");
      if (hash.startsWith(prefix)) break;
      nonce++;
      if ((nonce & 2047) === 0 && Date.now() - start > 1500) return null;
    }
    const vr = await fetch(`${origin}/api/pow/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        salt: ch.salt,
        difficulty: ch.difficulty,
        expires_at: ch.expires_at,
        signature: ch.signature,
        nonce: String(nonce)
      }),
      signal: AbortSignal.timeout(3500)
    });
    if (!vr.ok) return null;
    const vd = await vr.json();
    if (vd && vd.token) {
      cachedPowToken = { token: vd.token, expiresAt: Number(vd.expires_at || Date.now() / 1e3 + 300) };
      return vd.token;
    }
  } catch {
  }
  return null;
}
async function verifyStreamPlayable(url) {
  if (!url || !url.startsWith("http")) return false;
  try {
    const res = await fetch(url, {
      method: "GET",
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Range": "bytes=0-1023"
      },
      signal: AbortSignal.timeout(3500)
    });
    try {
      res.body?.cancel();
    } catch {
    }
    if (!res.ok && res.status !== 206) return false;
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    if (ct.includes("text/html") || ct.includes("text/plain") || ct.includes("application/json")) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}
async function resolveDirectDownloadStream(videoId, format) {
  const formatCode = format.toLowerCase().includes("mp3") ? "mp3" : format.includes("1080") ? "1080" : format.includes("480") ? "480" : format.includes("360") ? "360" : "720";
  const cacheKey = `${videoId}_${formatCode}`;
  const cached = directDownloadCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < 1e3 * 60 * 45) {
    return cached.url;
  }
  const existingPromise = inFlightResolutions.get(cacheKey);
  if (existingPromise) {
    return existingPromise;
  }
  const resolutionPromise = (async () => {
    const isAudio = formatCode === "mp3";
    for (const domain of ["https://p.savenow.to", "https://p.lbserver.xyz"]) {
      try {
        const powToken = await getSaveNowPowToken(domain);
        const reqHeaders = {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
          "Referer": "https://en.loader.to/"
        };
        if (powToken) {
          reqHeaders["Authorization"] = `Bearer ${powToken}`;
        }
        const apiUrl = `${domain}/api/v2/download?format=${encodeURIComponent(formatCode)}&url=${encodeURIComponent(`https://www.youtube.com/watch?v=${videoId}`)}&apikey=${SAVENOW_API_KEY}`;
        const initRes = await fetch(apiUrl, {
          headers: reqHeaders,
          signal: AbortSignal.timeout(4500)
        });
        if (initRes.ok) {
          const initData = await initRes.json();
          const progressUrl = initData.progress_url || (initData.id ? `${domain}/api/progress?id=${initData.id}` : null);
          if (progressUrl) {
            for (let i = 0; i < 24; i++) {
              await new Promise((r) => setTimeout(r, 900));
              try {
                const checkRes = await fetch(progressUrl, {
                  headers: reqHeaders,
                  signal: AbortSignal.timeout(3500)
                });
                if (checkRes.ok) {
                  const checkData = await checkRes.json();
                  if (checkData.download_url && typeof checkData.download_url === "string" && checkData.download_url.startsWith("http")) {
                    directDownloadCache.set(cacheKey, { url: checkData.download_url, timestamp: Date.now() });
                    return checkData.download_url;
                  }
                  if (checkData.success === -1 || checkData.text && String(checkData.text).toLowerCase().includes("error")) {
                    break;
                  }
                }
              } catch {
              }
            }
          }
        }
      } catch (err) {
        console.error(`SaveNow (${domain}) resolve error:`, err);
      }
    }
    try {
      const piped = await fetchPipedData(videoId);
      if (piped && piped.data) {
        const videoStreams = (piped.data.videoStreams || []).filter(
          (s) => s.url && s.url.startsWith("http") && s.url.includes("videoplayback") && s.format !== "HLS"
        );
        const audioStreams = (piped.data.audioStreams || []).filter(
          (s) => s.url && s.url.startsWith("http") && s.url.includes("videoplayback")
        );
        if (isAudio) {
          const audioCandidate = audioStreams[0]?.url || videoStreams.find((s) => !s.videoOnly)?.url;
          if (audioCandidate && await verifyStreamPlayable(audioCandidate)) {
            directDownloadCache.set(cacheKey, { url: audioCandidate, timestamp: Date.now() });
            return audioCandidate;
          }
        } else {
          const combined = videoStreams.filter((s) => !s.videoOnly);
          const exactMatch = combined.find((s) => (s.quality || "").includes(formatCode));
          const chosen = exactMatch || combined[0];
          if (chosen?.url && await verifyStreamPlayable(chosen.url)) {
            directDownloadCache.set(cacheKey, { url: chosen.url, timestamp: Date.now() });
            return chosen.url;
          }
        }
      }
    } catch {
    }
    try {
      const inv = await fetchInvidiousData(videoId);
      if (inv && inv.data) {
        if (isAudio) {
          const audioStreams = inv.data.adaptiveFormats?.filter((f) => f.type?.startsWith("audio")) || [];
          const candidateUrl = audioStreams[0]?.url || inv.data.formatStreams?.[0]?.url;
          if (candidateUrl && await verifyStreamPlayable(candidateUrl)) {
            directDownloadCache.set(cacheKey, { url: candidateUrl, timestamp: Date.now() });
            return candidateUrl;
          }
        } else {
          const formatStreams = inv.data.formatStreams || [];
          const matched = formatStreams.find((f) => (f.qualityLabel || "").includes(formatCode)) || formatStreams[0];
          if (matched?.url && await verifyStreamPlayable(matched.url)) {
            directDownloadCache.set(cacheKey, { url: matched.url, timestamp: Date.now() });
            return matched.url;
          }
        }
      }
    } catch {
    }
    try {
      const poTokenProvider = await (0, import_ytdl_core.createPoTokenProvider)({ timeoutMs: 3e3 });
      const ytdl = new import_ytdl_core.Ytdl({ poTokenProvider, clients: Object.values(import_ytdl_core.Client) });
      const ytdlInfo = await ytdl.getInfo(`https://www.youtube.com/watch?v=${videoId}`);
      if (ytdlInfo && Array.isArray(ytdlInfo.formats) && ytdlInfo.formats.length > 0) {
        if (isAudio) {
          const audioFmt = ytdlInfo.formats.find((f) => f.hasAudio && !f.hasVideo && f.url) || ytdlInfo.formats.find((f) => f.hasAudio && f.url);
          if (audioFmt?.url && await verifyStreamPlayable(audioFmt.url)) {
            directDownloadCache.set(cacheKey, { url: audioFmt.url, timestamp: Date.now() });
            return audioFmt.url;
          }
        } else {
          const muxed = ytdlInfo.formats.filter((f) => f.hasVideo && f.hasAudio && f.url);
          const matched = muxed.find((f) => String(f.qualityLabel || "").includes(formatCode)) || muxed[0];
          if (matched?.url && await verifyStreamPlayable(matched.url)) {
            directDownloadCache.set(cacheKey, { url: matched.url, timestamp: Date.now() });
            return matched.url;
          }
        }
      }
    } catch {
    }
    return null;
  })();
  inFlightResolutions.set(cacheKey, resolutionPromise);
  try {
    return await resolutionPromise;
  } finally {
    inFlightResolutions.delete(cacheKey);
  }
}
function extractVideoId(rawUrl) {
  if (!rawUrl) return null;
  const url = rawUrl.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(url)) {
    return url;
  }
  const regex = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=|shorts\/)|youtu\.be\/)([^"&?\/\s]{11})/i;
  const match = url.match(regex);
  if (match && match[1]) {
    return match[1];
  }
  return null;
}
async function searchYouTubeDirect(query) {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6e3);
    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&hl=ar&gl=EG`;
    const res = await fetch(searchUrl, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
      }
    });
    clearTimeout(timeoutId);
    if (!res.ok) return null;
    const html = await res.text();
    const dataMatch = html.match(/var ytInitialData\s*=\s*({.+?});<\/script>/s) || html.match(/window\["ytInitialData"\]\s*=\s*({.+?});<\/script>/s);
    if (!dataMatch) return null;
    const data = JSON.parse(dataMatch[1]);
    const sections = data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || [];
    const results = [];
    for (const section of sections) {
      const items = section?.itemSectionRenderer?.contents || [];
      for (const item of items) {
        const vr = item?.videoRenderer;
        if (vr && vr.videoId) {
          const title = vr.title?.runs?.map((r) => r.text).join("") || vr.title?.simpleText || "\u0641\u064A\u062F\u064A\u0648 \u064A\u0648\u062A\u064A\u0648\u0628";
          const author = vr.ownerText?.runs?.[0]?.text || vr.longBylineText?.runs?.[0]?.text || "\u0642\u0646\u0627\u0629 \u064A\u0648\u062A\u064A\u0648\u0628";
          const channelUrl = vr.ownerText?.runs?.[0]?.navigationEndpoint?.commandMetadata?.webCommandMetadata?.url ? `https://www.youtube.com${vr.ownerText.runs[0].navigationEndpoint.commandMetadata.webCommandMetadata.url}` : "";
          const authorAvatar = vr.channelThumbnailSupportedRenderers?.channelThumbnailWithLinkRenderer?.thumbnail?.thumbnails?.[0]?.url || "";
          const duration = vr.lengthText?.simpleText || "";
          const views = vr.viewCountText?.simpleText || vr.shortViewCountText?.simpleText || "";
          const published = vr.publishedTimeText?.simpleText || "";
          const snippet = vr.detailedMetadataSnippets?.[0]?.snippetText?.runs?.map((r) => r.text).join("") || "";
          const thumbs = vr.thumbnail?.thumbnails || [];
          const bestThumb = thumbs.length > 0 ? thumbs[thumbs.length - 1].url : `https://i.ytimg.com/vi/${vr.videoId}/hqdefault.jpg`;
          results.push({
            id: vr.videoId,
            title,
            description: snippet,
            author: {
              name: author,
              channelUrl,
              avatar: authorAvatar
            },
            duration,
            views,
            publishedTime: published,
            thumbnail: bestThumb,
            videoUrl: `https://www.youtube.com/watch?v=${vr.videoId}`,
            isShort: duration.includes(":") ? parseInt(duration.split(":")[0], 10) === 0 && parseInt(duration.split(":")[1], 10) <= 60 : false
          });
        }
      }
    }
    return results.length > 0 ? results : null;
  } catch (err) {
    console.error("Direct search error:", err);
    return null;
  }
}
async function searchInvidious(query) {
  const instances = getInvidiousInstances();
  for (const instance of instances) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4e3);
      const res = await fetch(`${instance}/api/v1/search?q=${encodeURIComponent(query)}&type=video`, {
        signal: controller.signal,
        headers: { "Accept": "application/json", "User-Agent": "Mozilla/5.0" }
      });
      clearTimeout(timeoutId);
      if (res.ok) {
        const list = await res.json();
        if (Array.isArray(list) && list.length > 0) {
          return list.map((item) => ({
            id: item.videoId,
            title: item.title,
            description: item.description || "",
            author: {
              name: item.author || "\u0642\u0646\u0627\u0629 \u064A\u0648\u062A\u064A\u0648\u0628",
              channelUrl: item.authorUrl ? `${instance}${item.authorUrl}` : "",
              avatar: item.authorThumbnails?.[0]?.url || ""
            },
            duration: formatDuration(item.lengthSeconds),
            views: formatViews(item.viewCount),
            publishedTime: item.publishedText || "",
            thumbnail: item.videoThumbnails?.[0]?.url || `https://i.ytimg.com/vi/${item.videoId}/hqdefault.jpg`,
            videoUrl: `https://www.youtube.com/watch?v=${item.videoId}`,
            isShort: item.lengthSeconds <= 60
          }));
        }
      }
    } catch {
    }
  }
  return null;
}
async function fetchInvidiousData(videoId) {
  const instances = getInvidiousInstances().slice(0, 5);
  try {
    return await Promise.any(
      instances.map(async (instance) => {
        const res = await fetch(`${instance}/api/v1/videos/${videoId}`, {
          signal: AbortSignal.timeout(2500),
          headers: {
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
          }
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data && data.title) {
          return { data, sourceInstance: instance };
        }
        throw new Error("Invalid data");
      })
    );
  } catch {
    return null;
  }
}
async function fetchPipedData(videoId) {
  const instances = getPipedInstances().slice(0, 4);
  try {
    return await Promise.any(
      instances.map(async (instance) => {
        const res = await fetch(`${instance}/streams/${videoId}`, {
          signal: AbortSignal.timeout(2500),
          headers: { "Accept": "application/json", "User-Agent": "Mozilla/5.0" }
        });
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const data = await res.json();
        if (data && data.title) {
          return { data, sourceInstance: instance };
        }
        throw new Error("Invalid data");
      })
    );
  } catch {
    return null;
  }
}
async function fetchOEmbedData(videoId) {
  try {
    const targetUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const res = await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(targetUrl)}&format=json`);
    if (res.ok) {
      return await res.json();
    }
  } catch {
  }
  return null;
}
var thumbnailCache = /* @__PURE__ */ new Map();
app.get(["/api/thumbnail", "/api/thumbnail/:id"], async (req, res) => {
  try {
    const videoId = req.params.id || req.query.id || req.query.videoId;
    if (!videoId || typeof videoId !== "string") {
      return res.status(400).send("\u0645\u0639\u0631\u0641 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0645\u0637\u0644\u0648\u0628");
    }
    const cleanId = videoId.replace(/[^a-zA-Z0-9_-]/g, "").trim();
    if (!cleanId) return res.status(400).send("\u0645\u0639\u0631\u0641 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
    const cacheKey = `thumb_${cleanId}`;
    const cached = thumbnailCache.get(cacheKey);
    if (cached && Date.now() - cached.timestamp < 1e3 * 60 * 60 * 24) {
      res.setHeader("Content-Type", cached.contentType);
      res.setHeader("Cache-Control", "public, max-age=86400, s-maxage=604800");
      res.setHeader("Access-Control-Allow-Origin", "*");
      return res.send(cached.buffer);
    }
    const candidateUrls = [
      `https://i.ytimg.com/vi/${cleanId}/maxresdefault.jpg`,
      `https://i.ytimg.com/vi/${cleanId}/hqdefault.jpg`,
      `https://i.ytimg.com/vi/${cleanId}/mqdefault.jpg`,
      `https://i.ytimg.com/vi/${cleanId}/default.jpg`
    ];
    for (const url of candidateUrls) {
      try {
        const response = await fetch(url, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
          },
          signal: AbortSignal.timeout(4e3)
        });
        if (response.ok) {
          const arrayBuf = await response.arrayBuffer();
          const buffer = Buffer.from(arrayBuf);
          const contentType = response.headers.get("content-type") || "image/jpeg";
          if (buffer.length > 1500) {
            thumbnailCache.set(cacheKey, { buffer, contentType, timestamp: Date.now() });
            res.setHeader("Content-Type", contentType);
            res.setHeader("Cache-Control", "public, max-age=86400, s-maxage=604800");
            res.setHeader("Access-Control-Allow-Origin", "*");
            return res.send(buffer);
          }
        }
      } catch {
      }
    }
    const fallbackLogo = import_path3.default.join(process.cwd(), "public", "logo.png");
    if (import_fs3.default.existsSync(fallbackLogo)) {
      res.setHeader("Content-Type", "image/png");
      res.setHeader("Cache-Control", "public, max-age=3600");
      res.setHeader("Access-Control-Allow-Origin", "*");
      return res.sendFile(fallbackLogo);
    }
    res.status(404).send("\u062A\u0639\u0630\u0631 \u062C\u0644\u0628 \u0635\u0648\u0631\u0629 \u0627\u0644\u0641\u064A\u062F\u064A\u0648");
  } catch (err) {
    console.error("Thumbnail proxy error:", err);
    if (!res.headersSent) {
      res.status(500).send("\u062E\u0637\u0623 \u0641\u064A \u0645\u0639\u0627\u0644\u062C\u0629 \u0635\u0648\u0631\u0629 \u0627\u0644\u0641\u064A\u062F\u064A\u0648");
    }
  }
});
app.get("/api/proxy-image", async (req, res) => {
  try {
    const targetUrl = req.query.url;
    if (!targetUrl || !targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
      return res.status(400).send("\u0631\u0627\u0628\u0637 \u0635\u0648\u0631\u0629 \u063A\u064A\u0631 \u0635\u0627\u0644\u062D");
    }
    const response = await fetch(targetUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "image/*,*/*"
      },
      signal: AbortSignal.timeout(5e3)
    });
    if (response.ok) {
      const contentType = response.headers.get("content-type") || "image/jpeg";
      const arrayBuf = await response.arrayBuffer();
      const buffer = Buffer.from(arrayBuf);
      res.setHeader("Content-Type", contentType);
      res.setHeader("Cache-Control", "public, max-age=86400");
      res.setHeader("Access-Control-Allow-Origin", "*");
      return res.send(buffer);
    }
    res.status(404).send("\u062A\u0639\u0630\u0631 \u062C\u0644\u0628 \u0627\u0644\u0635\u0648\u0631\u0629");
  } catch (err) {
    if (!res.headersSent) {
      res.status(500).send("\u062E\u0637\u0623 \u0641\u064A \u062C\u0644\u0628 \u0627\u0644\u0635\u0648\u0631\u0629");
    }
  }
});
app.get("/custom-logo.png", (req, res) => {
  const customPath = import_path3.default.join(process.cwd(), "public", "custom-logo.png");
  if (import_fs3.default.existsSync(customPath)) {
    res.setHeader("Content-Type", "image/png");
    res.setHeader("Cache-Control", "public, max-age=60");
    return res.sendFile(customPath);
  }
  res.setHeader("Content-Type", "image/png");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "logo.png"));
});
app.get("/custom-author.jpg", (req, res) => {
  const customPath = import_path3.default.join(process.cwd(), "public", "custom-author.jpg");
  if (import_fs3.default.existsSync(customPath)) {
    res.setHeader("Content-Type", "image/jpeg");
    res.setHeader("Cache-Control", "public, max-age=60");
    return res.sendFile(customPath);
  }
  res.setHeader("Content-Type", "image/jpeg");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "author.jpg"));
});
app.get(["/logo.png", "/logo.jpg"], (req, res) => {
  const customPath = import_path3.default.join(process.cwd(), "public", "custom-logo.png");
  if (import_fs3.default.existsSync(customPath)) {
    res.setHeader("Content-Type", "image/png");
    res.setHeader("Cache-Control", "public, max-age=60");
    return res.sendFile(customPath);
  }
  res.setHeader("Content-Type", "image/png");
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "logo.png"));
});
app.get("/sitemap.xml", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const currentBase = `${protocol}://${host}`;
  const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
  const sitemapXml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  <url>
    <loc>${currentBase}/</loc>
    <lastmod>${today}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
    <image:image>
      <image:loc>${currentBase}/logo.png</image:loc>
      <image:title>\u0634\u0639\u0627\u0631 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 - \u0645\u0648\u0642\u0639 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0631\u0633\u0645\u064A</image:title>
      <image:caption>\u0645\u0648\u0642\u0639 \u0648\u062A\u0637\u0628\u064A\u0642 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0631\u0633\u0645\u064A \u0644\u062A\u062D\u0645\u064A\u0644 \u0648\u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0645\u0642\u0627\u0637\u0639 \u0648\u0641\u064A\u062F\u064A\u0648\u0647\u0627\u062A \u0648\u0635\u0648\u062A\u064A\u0627\u062A \u0627\u0644\u064A\u0648\u062A\u064A\u0648\u0628 \u0644\u0644\u0645\u0637\u0648\u0631 \u062D\u0633\u0627\u0645 \u0623\u062D\u0645\u062F \u0645\u0633\u0627\u0639\u062F</image:caption>
    </image:image>
  </url>
  <url>
    <loc>${currentBase}/?source=pwa</loc>
    <lastmod>${today}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.8</priority>
  </url>
</urlset>`;
  res.setHeader("Content-Type", "application/xml; charset=utf-8");
  res.setHeader("Cache-Control", "public, max-age=3600");
  res.send(sitemapXml.trim());
});
app.get("/robots.txt", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const robotsTxt = `User-agent: *
Allow: /

Sitemap: ${baseUrl}/sitemap.xml
`;
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.send(robotsTxt);
});
app.get("/api/site-config", (req, res) => {
  try {
    const publicConfig = getPublicConfig();
    res.setHeader("Cache-Control", "no-cache");
    res.json(publicConfig);
  } catch (err) {
    res.status(500).json({ error: "Failed to retrieve site configuration" });
  }
});
app.post("/api/admin/login", (req, res) => {
  try {
    const { pin } = req.body;
    const authResult = authenticateAdmin(pin);
    if (authResult.success) {
      return res.json({ success: true, token: authResult.token, message: "\u062A\u0645 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0628\u0646\u062C\u0627\u062D" });
    } else {
      return res.status(401).json({ success: false, error: authResult.error || "\u0631\u0645\u0632 \u0627\u0644\u062F\u062E\u0648\u0644 \u063A\u064A\u0631 \u0635\u062D\u064A\u062D" });
    }
  } catch (err) {
    return res.status(500).json({ success: false, error: "\u062D\u062F\u062B \u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644" });
  }
});
function requireAdmin(req, res, next) {
  const authHeader = req.headers["authorization"] || "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim() || req.query.token;
  if (verifyAdminToken(token)) {
    return next();
  }
  return res.status(401).json({ error: "\u063A\u064A\u0631 \u0645\u0635\u0631\u062D \u0644\u0643 \u0628\u0627\u0644\u0648\u0635\u0648\u0644. \u064A\u0631\u062C\u0649 \u062A\u0633\u062C\u064A\u0644 \u0627\u0644\u062F\u062E\u0648\u0644 \u0623\u0648\u0644\u0627\u064B \u0643\u0645\u0633\u0624\u0648\u0644." });
}
app.get("/api/admin/config", requireAdmin, (req, res) => {
  try {
    const fullConfig = getActiveConfig();
    res.json(fullConfig);
  } catch (err) {
    res.status(500).json({ error: "Failed to retrieve admin config" });
  }
});
app.post("/api/admin/config", requireAdmin, (req, res) => {
  try {
    const updated = saveConfig(req.body);
    res.json({ success: true, message: "\u062A\u0645 \u062D\u0641\u0638 \u0648\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0628\u0646\u062C\u0627\u062D!", config: updated });
  } catch (err) {
    res.status(500).json({ error: `\u0641\u0634\u0644 \u062D\u0641\u0638 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A: ${err?.message || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}` });
  }
});
app.post("/api/admin/reset-config", requireAdmin, (req, res) => {
  try {
    const reset = saveConfig(DEFAULT_CONFIG);
    res.json({ success: true, message: "\u062A\u0645\u062A \u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629 \u0628\u0646\u062C\u0627\u062D!", config: reset });
  } catch (err) {
    res.status(500).json({ error: "\u0641\u0634\u0644 \u0627\u0633\u062A\u0639\u0627\u062F\u0629 \u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A \u0627\u0644\u0627\u0641\u062A\u0631\u0627\u0636\u064A\u0629" });
  }
});
app.post("/api/admin/upload-image", requireAdmin, (req, res) => {
  try {
    const { imageBase64, type } = req.body;
    if (!imageBase64 || typeof imageBase64 !== "string") {
      return res.status(400).json({ error: "\u0627\u0644\u0631\u062C\u0627\u0621 \u0625\u0631\u0633\u0627\u0644 \u0645\u0644\u0641 \u0627\u0644\u0635\u0648\u0631\u0629 \u0628\u0635\u064A\u063A\u0629 \u0635\u0627\u0644\u062D\u0629" });
    }
    const matches = imageBase64.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let buffer;
    let ext = "png";
    if (matches && matches.length === 3) {
      const mime = matches[1];
      if (mime.includes("jpeg") || mime.includes("jpg")) ext = "jpg";
      buffer = Buffer.from(matches[2], "base64");
    } else {
      buffer = Buffer.from(imageBase64, "base64");
    }
    const publicDir = import_path3.default.join(process.cwd(), "public");
    if (!import_fs3.default.existsSync(publicDir)) {
      import_fs3.default.mkdirSync(publicDir, { recursive: true });
    }
    const distDir = import_path3.default.join(process.cwd(), "dist");
    let targetFilename = "custom-logo.png";
    let configKey = "logoUrl";
    let dataUrlKey = "customLogoDataUrl";
    if (type === "author") {
      targetFilename = "custom-author.jpg";
      configKey = "authorImageUrl";
      dataUrlKey = "customAuthorDataUrl";
    }
    const targetPath = import_path3.default.join(publicDir, targetFilename);
    import_fs3.default.writeFileSync(targetPath, buffer);
    if (type === "logo") {
      try {
        import_fs3.default.writeFileSync(import_path3.default.join(publicDir, "logo.png"), buffer);
        import_fs3.default.writeFileSync(import_path3.default.join(publicDir, "logo.jpg"), buffer);
        import_fs3.default.writeFileSync(import_path3.default.join(publicDir, "favicon.png"), buffer);
        import_fs3.default.writeFileSync(import_path3.default.join(publicDir, "pwa-icon.png"), buffer);
        import_fs3.default.writeFileSync(import_path3.default.join(publicDir, "apple-touch-icon.png"), buffer);
      } catch (err) {
        console.error("Error updating public logo files:", err);
      }
      if (import_fs3.default.existsSync(distDir)) {
        try {
          import_fs3.default.writeFileSync(import_path3.default.join(distDir, "custom-logo.png"), buffer);
          import_fs3.default.writeFileSync(import_path3.default.join(distDir, "logo.png"), buffer);
          import_fs3.default.writeFileSync(import_path3.default.join(distDir, "logo.jpg"), buffer);
          import_fs3.default.writeFileSync(import_path3.default.join(distDir, "favicon.png"), buffer);
          import_fs3.default.writeFileSync(import_path3.default.join(distDir, "pwa-icon.png"), buffer);
        } catch {
        }
      }
      const assetsDir = import_path3.default.join(process.cwd(), "src", "assets", "images");
      if (import_fs3.default.existsSync(assetsDir)) {
        try {
          const files = import_fs3.default.readdirSync(assetsDir);
          for (const f of files) {
            if (f.startsWith("youtube_spell_logo_")) {
              import_fs3.default.writeFileSync(import_path3.default.join(assetsDir, f), buffer);
            }
          }
        } catch {
        }
      }
    } else {
      try {
        import_fs3.default.writeFileSync(import_path3.default.join(publicDir, "author.jpg"), buffer);
        if (import_fs3.default.existsSync(distDir)) {
          import_fs3.default.writeFileSync(import_path3.default.join(distDir, "author.jpg"), buffer);
          import_fs3.default.writeFileSync(import_path3.default.join(distDir, "custom-author.jpg"), buffer);
        }
      } catch {
      }
    }
    const publicUrl = `/${targetFilename}?v=${Date.now()}`;
    saveConfig({
      [configKey]: imageBase64,
      [dataUrlKey]: imageBase64
    });
    return res.json({
      success: true,
      url: imageBase64,
      dataUrl: imageBase64,
      publicUrl,
      message: `\u062A\u0645 \u062D\u0641\u0638 \u0648\u062A\u062B\u0628\u064A\u062A \u0635\u0648\u0631\u0629 ${type === "author" ? "\u0627\u0644\u0645\u0637\u0648\u0631" : "\u0627\u0644\u0634\u0639\u0627\u0631"} \u0628\u0646\u062C\u0627\u062D \u0648\u062F\u0627\u0626\u0645\u0627\u064B!`
    });
  } catch (err) {
    console.error("Image upload error:", err);
    return res.status(500).json({ error: `\u0641\u0634\u0644 \u0631\u0641\u0639 \u0627\u0644\u0635\u0648\u0631\u0629: ${err?.message || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u062A\u0648\u0642\u0639"}` });
  }
});
app.post("/api/admin/test-proxies", requireAdmin, async (req, res) => {
  try {
    const { instances, type } = req.body;
    const testList = Array.isArray(instances) && instances.length > 0 ? instances : type === "piped" ? getPipedInstances() : getInvidiousInstances();
    const results = await testProxyInstances(testList, type === "piped" ? "piped" : "invidious");
    return res.json({ results });
  } catch (err) {
    return res.status(500).json({ error: `\u0641\u0634\u0644 \u0641\u062D\u0635 \u0627\u0644\u0628\u0631\u0648\u0643\u0633\u064A\u0627\u062A: ${err?.message || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u062A\u0648\u0642\u0639"}` });
  }
});
app.get("/api/admin/vault/files", requireAdmin, (req, res) => {
  try {
    const items = getVaultItems();
    res.json({ success: true, items, count: items.length });
  } catch (err) {
    res.status(500).json({ error: "\u0641\u0634\u0644 \u0627\u0633\u062A\u0631\u062C\u0627\u0639 \u0645\u0644\u0641\u0627\u062A \u0627\u0644\u062E\u0632\u064A\u0646\u0629" });
  }
});
app.post("/api/admin/vault/upload", requireAdmin, (req, res) => {
  try {
    const { fileName, mimeType, fileBase64, deviceName, dimensions, duration } = req.body;
    if (!fileBase64 || typeof fileBase64 !== "string") {
      return res.status(400).json({ error: "\u0627\u0644\u0631\u062C\u0627\u0621 \u062A\u0648\u0641\u064A\u0631 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0644\u0641" });
    }
    const matches = fileBase64.match(/^data:([A-Za-z-+\/0-9]+);base64,(.+)$/);
    let buffer;
    let actualMime = mimeType || "application/octet-stream";
    if (matches && matches.length === 3) {
      actualMime = matches[1] || actualMime;
      buffer = Buffer.from(matches[2], "base64");
    } else {
      buffer = Buffer.from(fileBase64, "base64");
    }
    const item = saveVaultFile(
      fileName || `file_${Date.now()}`,
      actualMime,
      buffer,
      deviceName || "\u062C\u0647\u0627\u0632 \u0627\u0644\u0628\u064A\u062A",
      dimensions,
      duration
    );
    return res.json({ success: true, item, message: "\u062A\u0645\u062A \u0627\u0644\u0645\u0632\u0627\u0645\u0646\u0629 \u0628\u0646\u062C\u0627\u062D \u0625\u0644\u0649 \u0627\u0644\u062E\u0632\u064A\u0646\u0629!" });
  } catch (err) {
    console.error("Vault upload error:", err);
    return res.status(500).json({ error: `\u0641\u0634\u0644 \u0631\u0641\u0639 \u0627\u0644\u0645\u0644\u0641: ${err?.message || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}` });
  }
});
app.post("/api/vault/sync-download", (req, res) => {
  try {
    const { title, downloadUrl, thumbnailUrl, mediaType, deviceName } = req.body;
    if (!downloadUrl) {
      return res.status(400).json({ error: "\u0627\u0644\u0631\u062C\u0627\u0621 \u062A\u0648\u0641\u064A\u0631 \u0631\u0627\u0628\u0637 \u0627\u0644\u062A\u062D\u0645\u064A\u0644" });
    }
    const item = saveVaultItemFromDownload(
      title,
      downloadUrl,
      thumbnailUrl || "",
      mediaType || "video",
      deviceName || "\u0627\u0644\u0647\u0627\u062A\u0641 (\u062A\u0646\u0632\u064A\u0644\u0627\u062A \u0627\u0644\u0645\u0648\u0642\u0639)"
    );
    return res.json({ success: true, item, message: "\u062A\u0645\u062A \u0645\u0632\u0627\u0645\u0646\u0629 \u0648\u062D\u0641\u0638 \u0627\u0644\u062A\u0646\u0632\u064A\u0644 \u0641\u064A \u062E\u0632\u064A\u0646\u062A\u0643 \u0627\u0644\u0633\u062D\u0627\u0628\u064A\u0629 \u0628\u0646\u062C\u0627\u062D!" });
  } catch (err) {
    console.error("Error syncing download to vault:", err);
    return res.status(500).json({ error: "\u0641\u0634\u0644 \u0645\u0632\u0627\u0645\u0646\u0629 \u0627\u0644\u062A\u0646\u0632\u064A\u0644" });
  }
});
app.delete("/api/admin/vault/files/:id", requireAdmin, (req, res) => {
  try {
    const success = deleteVaultItem(req.params.id);
    if (success) {
      return res.json({ success: true, message: "\u062A\u0645 \u062D\u0630\u0641 \u0627\u0644\u0645\u0644\u0641 \u0628\u0646\u062C\u0627\u062D" });
    }
    return res.status(404).json({ error: "\u0627\u0644\u0645\u0644\u0641 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F" });
  } catch (err) {
    return res.status(500).json({ error: "\u0641\u0634\u0644 \u062D\u0630\u0641 \u0627\u0644\u0645\u0644\u0641" });
  }
});
app.post("/api/admin/vault/clear", requireAdmin, (req, res) => {
  try {
    clearAllVaultItems();
    return res.json({ success: true, message: "\u062A\u0645 \u062A\u0641\u0631\u064A\u063A \u0627\u0644\u062E\u0632\u064A\u0646\u0629 \u0628\u0646\u062C\u0627\u062D" });
  } catch (err) {
    return res.status(500).json({ error: "\u0641\u0634\u0644 \u0645\u0633\u062D \u0627\u0644\u062E\u0632\u064A\u0646\u0629" });
  }
});
app.post("/api/admin/vault/presence", requireAdmin, (req, res) => {
  try {
    const { id, deviceName, deviceType, isBroadcasting, filesCount } = req.body;
    const presence = updateDevicePresence({
      id: id || `dev_${req.ip}`,
      deviceName: deviceName || "\u062C\u0647\u0627\u0632 \u063A\u064A\u0631 \u0645\u0633\u0645\u0649",
      deviceType: deviceType || "phone",
      lastSeen: Date.now(),
      isBroadcasting: !!isBroadcasting,
      filesCount: filesCount || 0
    });
    const activeDevices = getActiveDevices();
    return res.json({ success: true, presence, activeDevices });
  } catch (err) {
    return res.status(500).json({ error: "Heartbeat error" });
  }
});
app.get("/api/admin/vault/presence", requireAdmin, (req, res) => {
  try {
    const activeDevices = getActiveDevices();
    return res.json({ success: true, activeDevices });
  } catch (err) {
    return res.status(500).json({ error: "Presence fetch error" });
  }
});
app.get("/vault_storage/:filename", (req, res) => {
  try {
    const filename = import_path3.default.basename(req.params.filename);
    const filePath = import_path3.default.join(process.cwd(), "public", "vault_storage", filename);
    if (!import_fs3.default.existsSync(filePath)) {
      return res.status(404).send("Media file not found");
    }
    const stat = import_fs3.default.statSync(filePath);
    const fileSize = stat.size;
    const range = req.headers.range;
    const ext = import_path3.default.extname(filename).toLowerCase();
    let contentType = "application/octet-stream";
    if ([".jpg", ".jpeg"].includes(ext)) contentType = "image/jpeg";
    else if ([".png"].includes(ext)) contentType = "image/png";
    else if ([".webp"].includes(ext)) contentType = "image/webp";
    else if ([".gif"].includes(ext)) contentType = "image/gif";
    else if ([".mp4", ".m4v"].includes(ext)) contentType = "video/mp4";
    else if ([".webm"].includes(ext)) contentType = "video/webm";
    else if ([".mp3"].includes(ext)) contentType = "audio/mpeg";
    const isDownload = req.query.download === "1" || req.query.dl === "true";
    if (isDownload) {
      res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    }
    if (range) {
      const parts = range.replace(/bytes=/, "").split("-");
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
      const chunksize = end - start + 1;
      const file = import_fs3.default.createReadStream(filePath, { start, end });
      const head = {
        "Content-Range": `bytes ${start}-${end}/${fileSize}`,
        "Accept-Ranges": "bytes",
        "Content-Length": chunksize,
        "Content-Type": contentType
      };
      res.writeHead(206, head);
      file.pipe(res);
    } else {
      const head = {
        "Content-Length": fileSize,
        "Content-Type": contentType,
        "Accept-Ranges": "bytes",
        "Cache-Control": "public, max-age=3600"
      };
      res.writeHead(200, head);
      import_fs3.default.createReadStream(filePath).pipe(res);
    }
  } catch (err) {
    console.error("Error serving vault storage file:", err);
    res.status(500).send("Internal error serving file");
  }
});
var VPN_SERVERS = [
  {
    id: "de-frankfurt-01",
    name: "\u0623\u0644\u0645\u0627\u0646\u064A\u0627 - \u0641\u0631\u0627\u0646\u0643\u0641\u0648\u0631\u062A (\u0633\u064A\u0631\u0641\u0631 \u0641\u0627\u0626\u0642 \u0627\u0644\u0633\u0631\u0639\u0629)",
    country: "\u0623\u0644\u0645\u0627\u0646\u064A\u0627",
    flag: "\u{1F1E9}\u{1F1EA}",
    city: "Frankfurt",
    ping: 28,
    type: "ultra_fast",
    features: ["\u062A\u062E\u0637\u064A \u062D\u062C\u0628 \u0627\u0644\u0645\u062F\u0627\u0631\u0633", "\u062A\u0634\u0641\u064A\u0631 DNS 1.1.1.1", "\u0633\u0631\u0639\u0629 \u0642\u0635\u0648\u0649 1Gbps", "\u062A\u062D\u0645\u064A\u0644 \u0645\u0628\u0627\u0634\u0631 \u0628\u062F\u0648\u0646 \u0642\u064A\u0648\u062F"]
  },
  {
    id: "fr-paris-02",
    name: "\u0641\u0631\u0646\u0633\u0627 - \u0628\u0627\u0631\u064A\u0633 (\u062E\u0627\u062F\u0645 \u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u0647\u0648\u064A\u0629 \u0627\u0644\u0645\u0634\u0641\u0631)",
    country: "\u0641\u0631\u0646\u0633\u0627",
    flag: "\u{1F1EB}\u{1F1F7}",
    city: "Paris",
    ping: 34,
    type: "stealth",
    features: ["\u062D\u0645\u0627\u064A\u0629 \u0627\u0644\u062A\u0627\u0628\u0644\u062A \u0627\u0644\u0645\u062F\u0631\u0633\u064A", "\u062A\u062C\u0627\u0648\u0632 \u062C\u062F\u0627\u0631 \u0627\u0644\u062D\u0645\u0627\u064A\u0629", "Zero-Logs", "\u062F\u0639\u0645 MP4/MP3"]
  },
  {
    id: "nl-amsterdam-01",
    name: "\u0647\u0648\u0644\u0646\u062F\u0627 - \u0623\u0645\u0633\u062A\u0631\u062F\u0627\u0645 (\u062A\u062E\u0637\u064A \u062D\u062C\u0628 \u0634\u0628\u0643\u0627\u062A \u0627\u0644\u062A\u0639\u0644\u064A\u0645)",
    country: "\u0647\u0648\u0644\u0646\u062F\u0627",
    flag: "\u{1F1F3}\u{1F1F1}",
    city: "Amsterdam",
    ping: 31,
    type: "school_unblocker",
    features: ["\u0645\u062E\u0635\u0635 \u0644\u0634\u0628\u0643\u0627\u062A \u0627\u0644\u0645\u062F\u0627\u0631\u0633", "\u062A\u062E\u0637\u064A \u0642\u064A\u0648\u062F \u064A\u0648\u062A\u064A\u0648\u0628 \u0648\u0648\u0632\u0627\u0631\u0629 \u0627\u0644\u062A\u0639\u0644\u064A\u0645", "\u062D\u0638\u0631 \u0627\u0644\u062A\u062A\u0628\u0639", "\u0628\u062B \u0645\u0628\u0627\u0634\u0631"]
  },
  {
    id: "us-newyork-01",
    name: "\u0623\u0645\u0631\u064A\u0643\u0627 - \u0646\u064A\u0648\u064A\u0648\u0631\u0643 (\u0646\u0641\u0642 \u0633\u062D\u0627\u0628\u064A \u0645\u0628\u0627\u0634\u0631)",
    country: "\u0623\u0645\u0631\u064A\u0643\u0627",
    flag: "\u{1F1FA}\u{1F1F8}",
    city: "New York",
    ping: 85,
    type: "ultra_fast",
    features: ["\u062A\u062E\u0637\u064A \u0627\u0644\u062D\u0638\u0631 \u0627\u0644\u062C\u063A\u0631\u0627\u0641\u064A", "\u0645\u062D\u062A\u0648\u0649 \u0623\u0645\u0631\u064A\u0643\u0627 \u0627\u0644\u0645\u0641\u062A\u0648\u062D", "\u0623\u0642\u0635\u0649 \u0623\u0645\u0627\u0646", "\u0645\u0646\u0627\u0641\u0630 \u0645\u0641\u062A\u0648\u062D\u0629"]
  },
  {
    id: "sg-singapore-01",
    name: "\u0633\u0646\u063A\u0627\u0641\u0648\u0631\u0629 - \u0622\u0633\u064A\u0627 (\u0646\u0641\u0642 \u0633\u0631\u064A\u0639)",
    country: "\u0633\u0646\u063A\u0627\u0641\u0648\u0631\u0629",
    flag: "\u{1F1F8}\u{1F1EC}",
    city: "Singapore",
    ping: 110,
    type: "p2p_direct",
    features: ["\u062A\u062E\u0637\u064A \u0642\u064A\u0648\u062F \u0645\u0632\u0648\u062F\u064A \u0627\u0644\u062E\u062F\u0645\u0629", "\u0633\u0631\u0639\u0629 \u0645\u062A\u0648\u0627\u0632\u0646\u0629", "SSL Tunneling"]
  }
];
app.get("/api/vpn/servers", (req, res) => {
  return res.json({
    success: true,
    servers: VPN_SERVERS,
    currentIp: req.headers["x-forwarded-for"] || req.socket.remoteAddress || "127.0.0.1",
    status: "online",
    encryption: "AES-256-GCM / WireTunnel"
  });
});
app.get("/api/vpn/ping/:serverId", (req, res) => {
  const server = VPN_SERVERS.find((s) => s.id === req.params.serverId);
  const basePing = server ? server.ping : 35;
  const simulatedJitter = Math.floor(Math.random() * 8) - 4;
  return res.json({
    serverId: req.params.serverId,
    ping: Math.max(12, basePing + simulatedJitter),
    status: "connected"
  });
});
app.all(["/api/vpn/proxy", "/api/vpn/unblock"], async (req, res) => {
  try {
    let targetUrl = req.query.url || req.body && req.body.url;
    if (!targetUrl) {
      return res.status(400).send("\u0627\u0644\u0631\u062C\u0627\u0621 \u062A\u0648\u0641\u064A\u0631 \u0627\u0644\u0631\u0627\u0628\u0637 \u0627\u0644\u0645\u0633\u062A\u0647\u062F\u0641 url");
    }
    if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
      targetUrl = `https://${targetUrl}`;
    }
    const parsedTarget = new URL(targetUrl);
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2e4);
    const headers = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
      "Accept": req.headers["accept"] || "*/*",
      "Accept-Language": "ar,en-US;q=0.9,en;q=0.8",
      "X-Forwarded-For": "194.26.29.11"
    };
    if (req.headers["range"]) {
      headers["Range"] = req.headers["range"];
    }
    const response = await fetch(targetUrl, {
      method: req.method === "POST" ? "POST" : "GET",
      headers,
      body: req.method === "POST" ? JSON.stringify(req.body) : void 0,
      signal: controller.signal,
      redirect: "follow"
    });
    clearTimeout(timeout);
    res.status(response.status);
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "*");
    res.setHeader("X-VPN-Proxied-By", "YouTube-Spell-Secure-Tunnel");
    res.setHeader("X-VPN-Node", "DE-Frankfurt-HighSpeed-1Gbps");
    const contentType = response.headers.get("content-type");
    if (contentType) res.setHeader("Content-Type", contentType);
    const contentLength = response.headers.get("content-length");
    if (contentLength) res.setHeader("Content-Length", contentLength);
    const contentRange = response.headers.get("content-range");
    if (contentRange) res.setHeader("Content-Range", contentRange);
    const acceptRanges = response.headers.get("accept-ranges");
    if (acceptRanges) res.setHeader("Accept-Ranges", acceptRanges);
    if (contentType && contentType.includes("text/html")) {
      let html = await response.text();
      const origin = parsedTarget.origin;
      html = html.replace("<head>", `<head><base href="${origin}/">`);
      return res.send(html);
    }
    if (!response.body) {
      return res.end();
    }
    const reader = response.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      const canWrite = res.write(value);
      if (!canWrite) {
        await new Promise((resolve) => res.once("drain", resolve));
      }
    }
    return res.end();
  } catch (err) {
    console.error("VPN Web Tunnel error:", err);
    if (!res.headersSent) {
      return res.status(500).send(`\u0641\u0634\u0644 \u0646\u0641\u0642 VPN \u0641\u064A \u062C\u0644\u0628 \u0627\u0644\u0635\u0641\u062D\u0629: ${err?.message || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u0639\u0631\u0648\u0641"}`);
    }
  }
});
app.get(["/pwa-icon.png", "/pwa-icon.jpg"], (req, res) => {
  res.setHeader("Content-Type", "image/png");
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "pwa-icon.png"));
});
app.get(["/author.jpg", "/author_full.jpg"], (req, res) => {
  res.setHeader("Content-Type", "image/jpeg");
  res.setHeader("Cache-Control", "public, max-age=86400");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "author.jpg"));
});
app.get(["/favicon.ico"], (req, res) => {
  res.setHeader("Content-Type", "image/x-icon");
  res.setHeader("Cache-Control", "public, max-age=604800");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "favicon.ico"));
});
app.get(["/favicon-48x48.png", "/favicon-96x96.png", "/favicon-144x144.png", "/favicon-192x192.png"], (req, res) => {
  const fileName = import_path3.default.basename(req.path);
  const filePath = import_path3.default.join(process.cwd(), "public", fileName);
  res.setHeader("Content-Type", "image/png");
  res.setHeader("Cache-Control", "public, max-age=604800");
  res.setHeader("Access-Control-Allow-Origin", "*");
  if (import_fs3.default.existsSync(filePath)) {
    return res.sendFile(filePath);
  }
  res.sendFile(import_path3.default.join(process.cwd(), "public", "favicon.png"));
});
app.get(["/apple-touch-icon.png", "/apple-touch-icon-precomposed.png"], (req, res) => {
  res.setHeader("Content-Type", "image/png");
  res.setHeader("Cache-Control", "public, max-age=604800");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "apple-touch-icon.png"));
});
app.get(["/favicon.png"], (req, res) => {
  res.setHeader("Content-Type", "image/png");
  res.setHeader("Cache-Control", "public, max-age=604800");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "favicon.png"));
});
app.get("/manifest.json", (req, res) => {
  res.setHeader("Content-Type", "application/manifest+json; charset=utf-8");
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "manifest.json"));
});
app.get("/sw.js", (req, res) => {
  res.setHeader("Content-Type", "application/javascript; charset=utf-8");
  res.setHeader("Service-Worker-Allowed", "/");
  res.sendFile(import_path3.default.join(process.cwd(), "public", "sw.js"));
});
app.get("/googleb0h4mpo8SnFahqUQW6X91KmDNLfURGL3l5sbIYcQmKM.html", (req, res) => {
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send("google-site-verification: googleb0h4mpo8SnFahqUQW6X91KmDNLfURGL3l5sbIYcQmKM.html");
});
app.get("/api/app-download/windows-bat", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const batContent = `@echo off
chcp 65001 >nul
title \u062A\u062B\u0628\u064A\u062A \u062A\u0637\u0628\u064A\u0642 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644
echo ====================================================
echo      \u062C\u0627\u0631\u064A \u062A\u062B\u0628\u064A\u062A \u062A\u0637\u0628\u064A\u0642 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0639\u0644\u0649 \u062C\u0647\u0627\u0632\u0643...
echo ====================================================
echo.

set "APP_URL=${baseUrl}"
set "APP_NAME=\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644"
set "DESKTOP_DIR=%USERPROFILE%Desktop"
set "SHORTCUT_PATH=%DESKTOP_DIR%%APP_NAME%.url"

:: Create Desktop Internet Shortcut
(
echo [InternetShortcut]
echo URL=%APP_URL%
echo IconIndex=0
echo IconFile=%APP_URL%/logo.png
) > "%SHORTCUT_PATH%"

:: Try to launch directly in Chrome / Edge App Mode
echo \u062A\u0645 \u0625\u0646\u0634\u0627\u0621 \u0627\u062E\u062A\u0635\u0627\u0631 \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0639\u0644\u0649 \u0633\u0637\u062D \u0627\u0644\u0645\u0643\u062A\u0628 \u0628\u0646\u062C\u0627\u062D!
echo \u062C\u0627\u0631\u064A \u0641\u062A\u062D \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0622\u0646...

start "" msedge.exe --app="%APP_URL%" 2>nul || start "" chrome.exe --app="%APP_URL%" 2>nul || start "" "%APP_URL%"

echo.
echo ====================================================
echo \u062A\u0645 \u0627\u0644\u062A\u062B\u0628\u064A\u062A \u0648\u0627\u0644\u062A\u0634\u063A\u064A\u0644 \u0628\u0646\u062C\u0627\u062D! \u0634\u0643\u0631\u0627\u064B \u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645\u0643 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644.
echo ====================================================
timeout /t 4 >nul
exit
`;
  res.setHeader("Content-Disposition", 'attachment; filename="SehrAlTahmeel-Setup.bat"');
  res.setHeader("Content-Type", "application/x-bat; charset=utf-8");
  res.send(batContent);
});
app.get("/api/app-download/windows-url", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const urlContent = `[InternetShortcut]
URL=${baseUrl}
IconIndex=0
IconFile=${baseUrl}/logo.png
`;
  res.setHeader("Content-Disposition", 'attachment; filename="SehrAlTahmeel.url"');
  res.setHeader("Content-Type", "application/internet-shortcut; charset=utf-8");
  res.send(urlContent);
});
app.get("/api/app-download/mac-command", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const shContent = `#!/bin/bash
echo "\u062C\u0627\u0631\u064A \u062A\u0634\u063A\u064A\u0644 \u062A\u0637\u0628\u064A\u0642 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644..."
open -na "Google Chrome" --args --app="${baseUrl}" 2>/dev/null || open -na "Microsoft Edge" --args --app="${baseUrl}" 2>/dev/null || open "${baseUrl}"
exit 0
`;
  res.setHeader("Content-Disposition", 'attachment; filename="SehrAlTahmeel-Mac.command"');
  res.setHeader("Content-Type", "application/x-sh; charset=utf-8");
  res.send(shContent);
});
app.get("/api/app-download/linux-desktop", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const desktopContent = `[Desktop Entry]
Version=1.0
Name=\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644
Comment=\u062A\u0637\u0628\u064A\u0642 \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648\u0647\u0627\u062A \u0648\u0627\u0644\u0635\u0648\u062A\u064A\u0627\u062A
Exec=google-chrome --app=${baseUrl}
Icon=${baseUrl}/logo.png
Terminal=false
Type=Application
Categories=AudioVideo;Audio;Video;
`;
  res.setHeader("Content-Disposition", 'attachment; filename="YoutubeSpell.desktop"');
  res.setHeader("Content-Type", "application/x-desktop; charset=utf-8");
  res.send(desktopContent);
});
app.get(["/privacy-policy", "/privacy"], (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 - \u062A\u0637\u0628\u064A\u0642 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644</title>
  <link rel="icon" type="image/png" href="/logo.png">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Tajawal', sans-serif;
      background: #0a0a0f;
      color: #e5e7eb;
      line-height: 1.8;
      padding: 30px 20px;
      max-width: 850px;
      margin: 0 auto;
    }
    h1 { color: #f59e0b; border-bottom: 2px solid #ef4444; padding-bottom: 12px; }
    h2 { color: #f87171; margin-top: 25px; }
    .card { background: #171722; padding: 25px; border-radius: 16px; border: 1px solid #2d2d3d; margin-bottom: 20px; }
    a { color: #fbbf24; text-decoration: none; }
    a:hover { text-decoration: underline; }
    .badge { display: inline-block; padding: 4px 12px; background: rgba(239,68,68,0.2); color: #f87171; border-radius: 20px; font-size: 13px; margin-bottom: 15px; }
  </style>
</head>
<body>
  <div class="card">
    <span class="badge">\u0627\u0644\u0648\u062B\u064A\u0642\u0629 \u0627\u0644\u0631\u0633\u0645\u064A\u0629 \u0644\u0645\u062A\u062C\u0631 \u0633\u0627\u0645\u0633\u0648\u0646\u062C \u0648\u0634\u0627\u0648\u0645\u064A \u0648\u062C\u0648\u062C\u0644</span>
    <h1>\u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 \u0648\u062A\u0623\u0643\u064A\u062F \u0627\u0644\u0623\u0645\u0627\u0646</h1>
    <p><strong>\u062A\u0637\u0628\u064A\u0642 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 (Sehr Al-Tahmeel)</strong> - \u0644\u0644\u0645\u0637\u0648\u0631: <strong>\u062D\u0633\u0627\u0645 \u0623\u062D\u0645\u062F \u0645\u0633\u0627\u0639\u062F</strong></p>
    <p>\u062A\u0627\u0631\u064A\u062E \u0622\u062E\u0631 \u062A\u062D\u062F\u064A\u062B: 18 \u0623\u063A\u0633\u0637\u0633 2026</p>
    
    <h2>1. \u062C\u0645\u0639 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A \u0648\u0627\u0644\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0634\u062E\u0635\u064A\u0629</h2>
    <p>\u064A\u0644\u062A\u0632\u0645 \u062A\u0637\u0628\u064A\u0642 <strong>\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644</strong> \u0628\u0623\u0639\u0644\u0649 \u0645\u0639\u0627\u064A\u064A\u0631 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 \u0648\u0627\u0644\u0623\u0645\u0627\u0646 \u0644\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u064A\u0646. <strong>\u0646\u062D\u0646 \u0644\u0627 \u0646\u062C\u0645\u0639 \u0623\u064A \u0628\u064A\u0627\u0646\u0627\u062A \u0634\u062E\u0635\u064A\u0629 \u0633\u0631\u064A\u0629 \u0623\u0648 \u0623\u0631\u0642\u0627\u0645 \u0647\u0648\u0627\u062A\u0641 \u0623\u0648 \u0643\u0644\u0645\u0627\u062A \u0645\u0631\u0648\u0631 \u0623\u0648 \u0633\u062C\u0644\u0627\u062A \u062A\u062A\u0628\u0639 \u0634\u062E\u0635\u064A\u0629.</strong> \u0639\u0645\u0644\u064A\u0627\u062A \u0627\u0644\u0628\u062D\u062B \u0648\u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u062A\u062A\u0645 \u0628\u0634\u0643\u0644 \u0645\u0628\u0627\u0634\u0631 \u0648\u0645\u0624\u0645\u0646.</p>
    
    <h2>2. \u0623\u0630\u0648\u0646\u0627\u062A \u0627\u0644\u062A\u0637\u0628\u064A\u0642 (App Permissions)</h2>
    <p>\u064A\u062A\u0637\u0644\u0628 \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u0623\u0630\u0648\u0646\u0627\u062A \u0627\u0644\u0642\u064A\u0627\u0633\u064A\u0629 \u0627\u0644\u062A\u0627\u0644\u064A\u0629 \u0641\u0642\u0637 \u0644\u0644\u0639\u0645\u0644 \u0628\u0627\u0644\u0634\u0643\u0644 \u0627\u0644\u0645\u0637\u0644\u0648\u0628:</p>
    <ul>
      <li><strong>\u0627\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A (INTERNET):</strong> \u0644\u0644\u0628\u062D\u062B \u0648\u062C\u0644\u0628 \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0627\u0644\u0645\u0642\u0627\u0637\u0639 \u0648\u0627\u0644\u0648\u0633\u0627\u0626\u0637.</li>
      <li><strong>\u062D\u0641\u0638 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0648\u062A\u0646\u0632\u064A\u0644\u0647\u0627 (WRITE/READ_EXTERNAL_STORAGE):</strong> \u0644\u062D\u0641\u0638 \u0627\u0644\u0645\u0642\u0627\u0637\u0639 \u0627\u0644\u0635\u0648\u062A\u064A\u0629 \u0648\u0627\u0644\u0645\u0631\u0626\u064A\u0629 \u0627\u0644\u062A\u064A \u064A\u062E\u062A\u0627\u0631 \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645 \u062A\u062D\u0645\u064A\u0644\u0647\u0627 \u0625\u0644\u0649 \u0630\u0627\u0643\u0631\u0629 \u0627\u0644\u062C\u0647\u0627\u0632.</li>
    </ul>

    <h2>3. \u062D\u0645\u0627\u064A\u0629 \u0648\u0623\u0645\u0627\u0646 \u0627\u0644\u0628\u064A\u0627\u0646\u0627\u062A</h2>
    <p>\u062C\u0645\u064A\u0639 \u0627\u0644\u0627\u062A\u0635\u0627\u0644\u0627\u062A \u0645\u0634\u0641\u0631\u0629 \u0628\u0628\u0631\u0648\u062A\u0648\u0643\u0648\u0644 \u0627\u0644\u062A\u0634\u0641\u064A\u0631 \u0627\u0644\u0622\u0645\u0646 <strong>HTTPS/SSL</strong> \u0648\u0644\u0627 \u064A\u062A\u0645 \u0628\u064A\u0639 \u0623\u0648 \u0645\u0634\u0627\u0631\u0643\u0629 \u0623\u064A \u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0645\u0639 \u0623\u064A \u0637\u0631\u0641 \u062B\u0627\u0644\u062B \u0639\u0644\u0649 \u0627\u0644\u0625\u0637\u0644\u0627\u0642.</p>

    <h2>4. \u062A\u0648\u0627\u0635\u0644 \u0645\u0639 \u0627\u0644\u0645\u0637\u0648\u0631</h2>
    <p>\u0644\u0623\u064A \u0627\u0633\u062A\u0641\u0633\u0627\u0631\u0627\u062A \u0623\u0648 \u062F\u0639\u0645 \u0641\u0646\u064A \u064A\u062E\u0635 \u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 \u0623\u0648 \u0645\u062A\u062C\u0631 \u0627\u0644\u062A\u0637\u0628\u064A\u0642\u0627\u062A:</p>
    <p>\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A: <a href="mailto:hos098sam@gmail.com">hos098sam@gmail.com</a></p>
    <p>\u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u0631\u0633\u0645\u064A: <a href="${baseUrl}">${baseUrl}</a></p>
    
    <hr style="border:0; border-top:1px solid #2d2d3d; margin:25px 0;">
    <p style="text-align:center; font-size:13px; color:#9ca3af;">\u062D\u0642\u0648\u0642 \u0627\u0644\u0646\u0634\u0631 \u0648\u0627\u0644\u062A\u0637\u0648\u064A\u0631 \xA9 2026 \u062D\u0633\u0627\u0645 \u0623\u062D\u0645\u062F \u0645\u0633\u0627\u0639\u062F. \u062C\u0645\u064A\u0639 \u0627\u0644\u062D\u0642\u0648\u0642 \u0645\u062D\u0641\u0648\u0638\u0629.</p>
  </div>
</body>
</html>`;
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(html);
});
app.get("/api/app-download/store-listing-ar.txt", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const text = `=====================================================================
\u0628\u064A\u0627\u0646\u0627\u062A \u0648\u0645\u0639\u0644\u0648\u0645\u0627\u062A \u0631\u0641\u0639 \u062A\u0637\u0628\u064A\u0642 "\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644" \u0639\u0644\u0649 \u0645\u062A\u062C\u0631 \u062C\u0644\u0627\u0643\u0633\u064A \u0648\u0645\u062A\u062C\u0631 \u0634\u0627\u0648\u0645\u064A
\u0627\u0644\u0645\u0637\u0648\u0631: \u062D\u0633\u0627\u0645 \u0623\u062D\u0645\u062F \u0645\u0633\u0627\u0639\u062F
=====================================================================

1. \u0627\u0633\u0645 \u0627\u0644\u062A\u0637\u0628\u064A\u0642 (App Title):
\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644

2. \u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A (English Title):
Sehr Al-Tahmeel - Media Downloader

3. \u0627\u0644\u0648\u0635\u0641 \u0627\u0644\u0642\u0635\u064A\u0631 (Short Description - 80 \u062D\u0631\u0641):
\u062A\u0637\u0628\u064A\u0642 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0644\u062A\u062D\u0645\u064A\u0644 \u0645\u0642\u0627\u0637\u0639 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0648\u0627\u0644\u0635\u0648\u062A\u064A\u0627\u062A MP3 \u0648 MP4 \u0628\u0623\u0639\u0644\u0649 \u062C\u0648\u062F\u0629 \u0648\u0633\u0631\u0639\u0629.

4. \u0627\u0644\u0648\u0635\u0641 \u0627\u0644\u0643\u0627\u0645\u0644 (Full Description):
\u062A\u0637\u0628\u064A\u0642 "\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644" \u0627\u0644\u0631\u0633\u0645\u064A \u0647\u0648 \u0627\u0644\u0623\u062F\u0627\u0629 \u0627\u0644\u0623\u0642\u0648\u0649 \u0648\u0627\u0644\u0623\u0633\u0647\u0644 \u0644\u0644\u0628\u062D\u062B \u0639\u0646 \u0645\u0642\u0627\u0637\u0639 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0648\u0627\u0644\u0635\u0648\u062A\u064A\u0627\u062A \u0648\u062A\u062D\u0645\u064A\u0644\u0647\u0627 \u0645\u0628\u0627\u0634\u0631\u0629 \u0625\u0644\u0649 \u062C\u0647\u0627\u0632\u0643 \u0628\u0623\u0639\u0644\u0649 \u062C\u0648\u062F\u0629 \u0645\u0645\u0643\u0646\u0629. \u0627\u0644\u0635\u0642 \u0627\u0644\u0631\u0627\u0628\u0637 \u0648\u0633\u064A\u0628 \u0627\u0644\u0633\u062D\u0631 \u0639\u0644\u064A\u0646\u0627!

\u2728 \u0623\u0628\u0631\u0632 \u0645\u0645\u064A\u0632\u0627\u062A \u0627\u0644\u062A\u0637\u0628\u064A\u0642:
\u2022 \u0645\u062D\u0631\u0643 \u0628\u062D\u062B \u0641\u0648\u0631\u064A \u0648\u0633\u0631\u064A\u0639 \u0644\u0644\u0648\u0635\u0648\u0644 \u0625\u0644\u0649 \u0623\u064A \u0645\u0642\u0637\u0639.
\u2022 \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0628\u062C\u0648\u062F\u0627\u062A \u0645\u062A\u0639\u062F\u062F\u0629: 4K, 1080p Full HD, 720p, 480p, 360p.
\u2022 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0627\u0644\u0635\u0648\u062A \u0628\u0635\u064A\u063A\u0629 MP3 \u0648 M4A \u0628\u0646\u0642\u0627\u0621 \u0635\u0648\u062A \u0627\u0633\u062A\u0648\u062F\u064A\u0648 \u0641\u0627\u0626\u0642 320kbps.
\u2022 \u0645\u0634\u063A\u0644 \u0641\u064A\u062F\u064A\u0648 \u0648\u0635\u0648\u062A \u0645\u062F\u0645\u062C \u0644\u0645\u0639\u0627\u064A\u0646\u0629 \u0627\u0644\u0645\u0642\u0627\u0637\u0639 \u0642\u0628\u0644 \u0627\u0644\u062A\u062D\u0645\u064A\u0644.
\u2022 \u062F\u0639\u0645 \u0643\u0627\u0645\u0644 \u0644\u062A\u0627\u0628\u0644\u062A \u0627\u0644\u062B\u0627\u0646\u0648\u064A\u0629 \u0627\u0644\u0639\u0627\u0645\u0629 \u0648\u0647\u0648\u0627\u062A\u0641 \u0633\u0627\u0645\u0633\u0648\u0646\u062C \u0648\u0634\u0627\u0648\u0645\u064A \u0648\u062C\u0645\u064A\u0639 \u0623\u062C\u0647\u0632\u0629 \u0623\u0646\u062F\u0631\u0648\u064A\u062F.
\u2022 \u062E\u0641\u064A\u0641 \u0648\u0633\u0631\u064A\u0639 \u0648\u0644\u0627 \u064A\u0633\u062A\u0647\u0644\u0643 \u0628\u0637\u0627\u0631\u064A\u0629 \u0627\u0644\u062C\u0647\u0627\u0632 \u0623\u0648 \u0627\u0644\u0630\u0627\u0643\u0631\u0629.
\u2022 \u0648\u0627\u062C\u0647\u0629 \u0639\u0631\u0628\u064A\u0629 \u0639\u0635\u0631\u064A\u0629 \u0648\u0633\u0647\u0644\u0629 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0645\u0639 \u062F\u0639\u0645 \u0627\u0644\u0648\u0636\u0639 \u0627\u0644\u0644\u064A\u0644\u064A (Dark Mode).

\u0627\u0644\u0645\u0637\u0648\u0631: \u062D\u0633\u0627\u0645 \u0623\u062D\u0645\u062F \u0645\u0633\u0627\u0639\u062F
\u0627\u0644\u0628\u0631\u064A\u062F \u0627\u0644\u0625\u0644\u0643\u062A\u0631\u0648\u0646\u064A \u0644\u0644\u062F\u0639\u0645: hos098sam@gmail.com
\u0627\u0644\u0645\u0648\u0642\u0639 \u0627\u0644\u0631\u0633\u0645\u064A: ${baseUrl}

5. \u0627\u0644\u0643\u0644\u0645\u0627\u062A \u0627\u0644\u0645\u0641\u062A\u0627\u062D\u064A\u0629 (Keywords / Tags):
\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644, \u062A\u062D\u0645\u064A\u0644 \u0645\u0642\u0627\u0637\u0639, \u062A\u0646\u0632\u064A\u0644 \u0641\u064A\u062F\u064A\u0648, \u062A\u062D\u0648\u064A\u0644 mp3, \u062D\u0633\u0627\u0645 \u0623\u062D\u0645\u062F \u0645\u0633\u0627\u0639\u062F, media downloader, sehr altahmeel, mp3 converter, 4k video downloader

6. \u0627\u0644\u0641\u0626\u0629 (Category):
Tools & Utilities (\u0623\u062F\u0648\u0627\u062A \u0648\u0645\u0631\u0627\u0641\u0642) \u0623\u0648 Video Players & Editors (\u0645\u0634\u063A\u0644\u0627\u062A \u0648\u062A\u0637\u0628\u064A\u0642\u0627\u062A \u0627\u0644\u0641\u064A\u062F\u064A\u0648)

7. \u0627\u0644\u0641\u0626\u0629 \u0627\u0644\u0639\u0645\u0631\u064A\u0629 (Content Rating):
Everyone / \u0645\u0646\u0627\u0633\u0628 \u0644\u062C\u0645\u064A\u0639 \u0627\u0644\u0623\u0639\u0645\u0627\u0631 (3+)

8. \u0631\u0627\u0628\u0637 \u0633\u064A\u0627\u0633\u0629 \u0627\u0644\u062E\u0635\u0648\u0635\u064A\u0629 (Privacy Policy URL):
${baseUrl}/privacy-policy

9. \u0627\u0633\u0645 \u0627\u0644\u062D\u0632\u0645\u0629 \u0627\u0644\u0628\u0631\u0645\u062C\u064A\u0629 (Package Name):
com.hossam.youtubespell

10. \u0631\u0642\u0645 \u0627\u0644\u0625\u0635\u062F\u0627\u0631 (Version):
Version Name: 1.0.0
Version Code: 1
`;
  res.setHeader("Content-Disposition", 'attachment; filename="Store_Listing_Arabic.txt"');
  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.send(text);
});
app.get("/api/app-download/android-manifest.xml", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const manifestXml = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.hossam.youtubespell"
    android:versionCode="1"
    android:versionName="1.0.0">

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen"
        android:usesCleartextTraffic="true">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>

            <!-- Deep linking for YouTube Spell URL -->
            <intent-filter android:autoVerify="true">
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data
                    android:scheme="https"
                    android:host="${host}" />
            </intent-filter>
        </activity>

        <meta-data
            android:name="asset_statements"
            android:value="[{'relation': ['delegate_permission/common.handle_all_urls'], 'target': {'namespace': 'web', 'site': '${baseUrl}'}}]" />
    </application>
</manifest>`;
  res.setHeader("Content-Disposition", 'attachment; filename="AndroidManifest.xml"');
  res.setHeader("Content-Type", "application/xml; charset=utf-8");
  res.send(manifestXml);
});
app.get("/api/app-download/twa-manifest.json", (req, res) => {
  const host = req.get("host") || "ais-pre-3shdpnkbumvwgb2e6bb5ff-514857695585.europe-west2.run.app";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;
  const twaJson = {
    packageId: "com.hossam.sehraltahmeel",
    host,
    name: "\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644",
    launcherName: "\u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644",
    themeColor: "#0a0a0f",
    navigationColor: "#0a0a0f",
    backgroundColor: "#0a0a0f",
    enableNotifications: true,
    startUrl: "/",
    iconUrl: `${baseUrl}/logo.png`,
    maskableIconUrl: `${baseUrl}/logo.png`,
    splashScreenFadeOutDuration: 300,
    appVersionName: "1.0.0",
    appVersionCode: 1,
    signingKey: {
      alias: "android",
      storeFile: "android.keystore"
    },
    generator: "PWABuilder / Bubblewrap",
    author: "\u062D\u0633\u0627\u0645 \u0623\u062D\u0645\u062F \u0645\u0633\u0627\u0639\u062F",
    storeListing: {
      galaxyStore: "https://seller.samsungapps.com/",
      xiaomiStore: "https://global.developer.mi.com/"
    }
  };
  res.setHeader("Content-Disposition", 'attachment; filename="twa-manifest.json"');
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.send(JSON.stringify(twaJson, null, 2));
});
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", time: (/* @__PURE__ */ new Date()).toISOString() });
});
app.get("/api/suggestions", async (req, res) => {
  try {
    const q = req.query.q;
    if (!q || !q.trim()) {
      return res.json([]);
    }
    const suggestUrl = `https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=${encodeURIComponent(q.trim())}&hl=ar`;
    const response = await fetch(suggestUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
      }
    });
    if (response.ok) {
      const data = await response.json();
      const suggestions = Array.isArray(data?.[1]) ? data[1] : [];
      return res.json(suggestions.slice(0, 10));
    }
    return res.json([]);
  } catch (error) {
    return res.json([]);
  }
});
app.get("/api/search", async (req, res) => {
  try {
    const query = req.query.q;
    if (!query || !query.trim()) {
      return res.status(400).json({ error: "\u0627\u0644\u0631\u062C\u0627\u0621 \u0625\u062F\u062E\u0627\u0644 \u0643\u0644\u0645\u0629 \u0628\u062D\u062B \u0644\u0644\u0628\u062D\u062B \u0641\u064A \u064A\u0648\u062A\u064A\u0648\u0628" });
    }
    const cleanQuery = query.trim();
    const extractedId = extractVideoId(cleanQuery);
    if (extractedId) {
      return res.json({
        isDirectUrl: true,
        videoId: extractedId,
        results: []
      });
    }
    let results = await searchYouTubeDirect(cleanQuery);
    if (!results || results.length === 0) {
      results = await searchInvidious(cleanQuery);
    }
    if (!results || results.length === 0) {
      return res.json({
        query: cleanQuery,
        total: 0,
        results: []
      });
    }
    return res.json({
      query: cleanQuery,
      total: results.length,
      results
    });
  } catch (error) {
    console.error("Search error:", error);
    return res.status(500).json({ error: `\u0641\u0634\u0644 \u0627\u0644\u0628\u062D\u062B: ${error?.message || "\u062E\u0637\u0623 \u063A\u064A\u0631 \u0645\u062A\u0648\u0642\u0639"}` });
  }
});
async function fetchFallbackVideoDuration(videoId) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3500);
    const res = await fetch(`https://www.youtube.com/watch?v=${videoId}`, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Accept-Language": "en-US,en;q=0.9,ar;q=0.8"
      },
      signal: controller.signal
    });
    clearTimeout(timeout);
    if (res.ok) {
      const html = await res.text();
      const msMatch = html.match(/"approxDurationMs":"(\d+)"/);
      if (msMatch && msMatch[1]) {
        const s = Math.round(parseInt(msMatch[1], 10) / 1e3);
        if (s > 0) return s;
      }
      const secMatch = html.match(/"lengthSeconds":"(\d+)"/);
      if (secMatch && secMatch[1]) {
        const s = parseInt(secMatch[1], 10);
        if (s > 0) return s;
      }
      const isoMatch = html.match(/itemprop="duration" content="PT([^"]+)"/);
      if (isoMatch && isoMatch[1]) {
        const iso = isoMatch[1];
        let total = 0;
        const hours = iso.match(/(\d+)H/);
        const mins = iso.match(/(\d+)M/);
        const secs = iso.match(/(\d+)S/);
        if (hours) total += parseInt(hours[1], 10) * 3600;
        if (mins) total += parseInt(mins[1], 10) * 60;
        if (secs) total += parseInt(secs[1], 10);
        if (total > 0) return total;
      }
    }
  } catch {
  }
  return 0;
}
function calculateFormatSizeMb(format, durationSeconds) {
  if (!format) return "\u063A\u064A\u0631 \u0645\u062D\u062F\u062F";
  if (typeof format.size === "string" && /^\s*[\d\.]+\s*(MB|GB|KB)\s*$/i.test(format.size)) {
    return format.size.trim().toUpperCase();
  }
  const candidateBytes = format.contentLength || format.clen || format.filesize || format.fileSize || format.size;
  if (candidateBytes !== void 0 && candidateBytes !== null) {
    const rawStr = String(candidateBytes).trim();
    if (/^\d+$/.test(rawStr)) {
      const numBytes = parseInt(rawStr, 10);
      if (numBytes > 1024) {
        if (numBytes >= 1024 * 1024 * 1024) {
          return `${(numBytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
        }
        return `${(numBytes / (1024 * 1024)).toFixed(1)} MB`;
      }
    }
  }
  const duration = durationSeconds > 0 ? durationSeconds : 210;
  const isAudioOnly = !format.hasVideo || format.ext === "mp3" || format.container === "mp3" || format.container === "m4a" || format.container === "opus" || format.ext === "opus" || format.ext === "m4a";
  if (isAudioOnly) {
    let audioBitrateKbps = 128;
    if (format.bitrate && !isNaN(Number(format.bitrate))) {
      const b = Number(format.bitrate);
      audioBitrateKbps = b > 5e3 ? Math.round(b / 1e3) : b;
    } else if (typeof format.quality === "string") {
      if (format.quality.includes("320")) audioBitrateKbps = 320;
      else if (format.quality.includes("256")) audioBitrateKbps = 256;
      else if (format.quality.includes("192")) audioBitrateKbps = 192;
      else if (format.quality.includes("128")) audioBitrateKbps = 128;
      else if (format.quality.includes("96")) audioBitrateKbps = 96;
      else if (format.quality.includes("64")) audioBitrateKbps = 64;
    }
    const mb = audioBitrateKbps * 1e3 * duration / (8 * 1024 * 1024);
    return `${Math.max(0.4, mb).toFixed(1)} MB`;
  }
  let videoBitrateKbps = 0;
  if (format.bitrate && !isNaN(Number(format.bitrate))) {
    const b = Number(format.bitrate);
    const normalized = b > 5e3 ? Math.round(b / 1e3) : b;
    if (normalized >= 150 && normalized <= 5e4) {
      videoBitrateKbps = normalized;
    }
  }
  if (!videoBitrateKbps) {
    const height = format.height || parseInt(String(format.quality || format.qualityLabel || "").replace(/\D/g, ""), 10) || 720;
    const is60fps = format.fps && format.fps >= 50;
    if (height >= 2160) videoBitrateKbps = is60fps ? 18e3 : 13e3;
    else if (height >= 1440) videoBitrateKbps = is60fps ? 9500 : 6500;
    else if (height >= 1080) videoBitrateKbps = is60fps ? 4200 : 3e3;
    else if (height >= 720) videoBitrateKbps = is60fps ? 2400 : 1600;
    else if (height >= 480) videoBitrateKbps = 850;
    else if (height >= 360) videoBitrateKbps = 450;
    else if (height >= 240) videoBitrateKbps = 260;
    else videoBitrateKbps = 160;
  }
  const totalBitrateKbps = format.hasAudio ? videoBitrateKbps + 128 : videoBitrateKbps;
  const calculatedMb = totalBitrateKbps * 1e3 * duration / (8 * 1024 * 1024);
  if (calculatedMb >= 1024) {
    return `${(calculatedMb / 1024).toFixed(2)} GB`;
  }
  return `${Math.max(0.6, calculatedMb).toFixed(1)} MB`;
}
app.post("/api/extract", async (req, res) => {
  try {
    const { url } = req.body;
    if (!url || typeof url !== "string" || !url.trim()) {
      return res.status(400).json({ error: "\u0627\u0644\u0631\u062C\u0627\u0621 \u0625\u062F\u062E\u0627\u0644 \u0631\u0627\u0628\u0637 \u0641\u064A\u062F\u064A\u0648 \u0623\u0648 \u0643\u0644\u0645\u0629 \u0628\u062D\u062B \u0635\u062D\u064A\u062D\u0629" });
    }
    let videoId = extractVideoId(url);
    if (!videoId) {
      const searchResults = await searchYouTubeDirect(url.trim());
      if (searchResults && searchResults.length > 0) {
        videoId = searchResults[0].id;
      }
    }
    if (!videoId) {
      return res.status(400).json({ error: "\u062A\u0639\u0630\u0631 \u0627\u0644\u0639\u062B\u0648\u0631 \u0639\u0644\u0649 \u0627\u0644\u0641\u064A\u062F\u064A\u0648. \u064A\u0631\u062C\u0649 \u0627\u0644\u062A\u062D\u0642\u0642 \u0645\u0646 \u0627\u0644\u0631\u0627\u0628\u0637 \u0623\u0648 \u0627\u0644\u0643\u0644\u0645\u0627\u062A \u0627\u0644\u0645\u062F\u062E\u0644\u0629." });
    }
    const targetUrl = `https://www.youtube.com/watch?v=${videoId}`;
    const oembedPromise = fetchOEmbedData(videoId);
    const invidiousPromise = fetchInvidiousData(videoId);
    const [oembed, invidiousResult] = await Promise.all([oembedPromise, invidiousPromise]);
    let title = oembed?.title || "\u0641\u064A\u062F\u064A\u0648 \u064A\u0648\u062A\u064A\u0648\u0628";
    let authorName = oembed?.author_name || "\u0635\u0627\u062D\u0628 \u0627\u0644\u0642\u0646\u0627\u0629";
    let authorUrl = oembed?.author_url || `https://www.youtube.com/channel/${videoId}`;
    let durationSeconds = 0;
    let viewCount = 0;
    let combinedFormats = [];
    let audioFormats = [];
    let highDefFormats = [];
    if (invidiousResult && invidiousResult.data) {
      const invData = invidiousResult.data;
      if (invData.title) title = invData.title;
      if (invData.author) authorName = invData.author;
      if (invData.authorUrl) authorUrl = invData.authorUrl;
      durationSeconds = invData.lengthSeconds || 0;
      viewCount = invData.viewCount || 0;
      if (durationSeconds <= 0) {
        durationSeconds = await fetchFallbackVideoDuration(videoId);
      }
      const formatStreams = invData.formatStreams || [];
      const seenQualities = /* @__PURE__ */ new Set();
      for (const f of formatStreams) {
        const quality = f.qualityLabel || (f.resolution ? `${f.resolution}` : "MP4");
        const sizeMb = f.size ? (parseInt(f.size, 10) / (1024 * 1024)).toFixed(1) : null;
        const itag = f.itag || Math.floor(Math.random() * 1e3);
        if (!seenQualities.has(quality)) {
          seenQualities.add(quality);
          const rawMediaUrl = f.url || "";
          combinedFormats.push({
            itag,
            quality,
            height: parseInt(quality.replace(/\D/g, ""), 10) || 720,
            ext: (f.container || f.ext || "mp4").toLowerCase(),
            hasVideo: true,
            hasAudio: true,
            size: calculateFormatSizeMb(f, durationSeconds),
            directUrl: rawMediaUrl,
            downloadUrl: `/api/stream-proxy?url=${encodeURIComponent(rawMediaUrl)}&title=${encodeURIComponent(title)}&ext=mp4`,
            fps: f.fps || 30
          });
        }
      }
      const adaptiveFormats = invData.adaptiveFormats || [];
      const seenAdaptive = /* @__PURE__ */ new Set();
      for (const f of adaptiveFormats) {
        if (f.type?.startsWith("video") && f.qualityLabel) {
          const key = `${f.qualityLabel}_${f.container || f.ext}`;
          if (!seenAdaptive.has(key)) {
            seenAdaptive.add(key);
            const itag = f.itag || Math.floor(Math.random() * 1e3);
            const rawMediaUrl = f.url || "";
            highDefFormats.push({
              itag,
              quality: f.qualityLabel,
              height: parseInt(f.qualityLabel.replace(/\D/g, ""), 10) || 1080,
              ext: (f.container || f.ext || "mp4").toLowerCase(),
              container: f.container || "mp4",
              hasVideo: true,
              hasAudio: false,
              size: calculateFormatSizeMb(f, durationSeconds),
              directUrl: rawMediaUrl,
              downloadUrl: `/api/stream-proxy?url=${encodeURIComponent(rawMediaUrl)}&title=${encodeURIComponent(title)}&ext=${f.container || "mp4"}`,
              fps: f.fps || 30
            });
          }
        }
        if (f.type?.startsWith("audio") || f.audioQuality) {
          const bitrate = f.bitrate ? Math.round(parseInt(f.bitrate, 10) / 1e3) : 128;
          const container = (f.container || f.ext || "m4a").toLowerCase();
          const key = `${bitrate}kbps_${container}`;
          if (!seenAdaptive.has(key)) {
            seenAdaptive.add(key);
            const itag = f.itag || Math.floor(Math.random() * 1e3);
            const rawMediaUrl = f.url || "";
            audioFormats.push({
              itag,
              quality: `${bitrate} kbps (${container.toUpperCase()})`,
              bitrate,
              ext: container === "webm" ? "webm" : "m4a",
              container,
              hasVideo: false,
              hasAudio: true,
              size: calculateFormatSizeMb({ ...f, bitrate, hasVideo: false, hasAudio: true }, durationSeconds),
              directUrl: rawMediaUrl,
              downloadUrl: `/api/stream-proxy?url=${encodeURIComponent(rawMediaUrl)}&title=${encodeURIComponent(title)}&ext=${container === "webm" ? "webm" : "m4a"}`
            });
          }
        }
      }
    }
    if (combinedFormats.length === 0) {
      const pipedResult = await fetchPipedData(videoId);
      if (pipedResult && pipedResult.data) {
        const pipedData = pipedResult.data;
        if (pipedData.title) title = pipedData.title;
        if (pipedData.uploader) authorName = pipedData.uploader;
        if (pipedData.duration) durationSeconds = pipedData.duration;
        if (pipedData.views) viewCount = pipedData.views;
        const videoStreams = (pipedData.videoStreams || []).filter(
          (s) => s.url && s.url.startsWith("http") && s.url.includes("videoplayback") && s.format !== "HLS"
        );
        const seenPiped = /* @__PURE__ */ new Set();
        for (const s of videoStreams) {
          if (!s.videoOnly) {
            const quality = s.quality || `${s.height || 720}p`;
            if (!seenPiped.has(quality)) {
              seenPiped.add(quality);
              const itag = s.itag || Math.floor(Math.random() * 1e3);
              combinedFormats.push({
                itag,
                quality,
                height: s.height || 720,
                ext: (s.format || "mp4").toLowerCase(),
                hasVideo: true,
                hasAudio: true,
                size: calculateFormatSizeMb(s, durationSeconds),
                directUrl: s.url,
                downloadUrl: `/api/stream-proxy?url=${encodeURIComponent(s.url)}&title=${encodeURIComponent(title)}&ext=mp4`,
                fps: s.fps || 30
              });
            }
          }
        }
        const pipedAudio = (pipedData.audioStreams || []).filter(
          (a) => a.url && a.url.startsWith("http") && a.url.includes("videoplayback")
        );
        for (const a of pipedAudio) {
          const bitrate = a.bitrate ? Math.round(parseInt(a.bitrate, 10) / 1e3) : 128;
          const container = (a.format || "m4a").toLowerCase();
          const itag = a.itag || Math.floor(Math.random() * 1e3);
          audioFormats.push({
            itag,
            quality: `${bitrate} kbps (${container.toUpperCase()})`,
            bitrate,
            ext: container === "webm" ? "webm" : "m4a",
            container,
            hasVideo: false,
            hasAudio: true,
            size: calculateFormatSizeMb({ ...a, bitrate, hasVideo: false, hasAudio: true }, durationSeconds),
            directUrl: a.url,
            downloadUrl: `/api/stream-proxy?url=${encodeURIComponent(a.url)}&title=${encodeURIComponent(title)}&ext=${container === "webm" ? "webm" : "m4a"}`
          });
        }
      }
    }
    combinedFormats.sort((a, b) => (b.height || 0) - (a.height || 0));
    highDefFormats.sort((a, b) => (b.height || 0) - (a.height || 0));
    audioFormats.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
    if (durationSeconds <= 0) {
      durationSeconds = await fetchFallbackVideoDuration(videoId);
    }
    const existingHeights = new Set(combinedFormats.map((f) => f.height));
    const standardVideoPresets = [
      { itag: 1080, quality: "1080p Full HD", height: 1080, fps: 60 },
      { itag: 720, quality: "720p HD", height: 720, fps: 30 },
      { itag: 480, quality: "480p SD", height: 480, fps: 30 },
      { itag: 360, quality: "360p", height: 360, fps: 30 }
    ];
    for (const preset of standardVideoPresets) {
      if (!existingHeights.has(preset.height)) {
        combinedFormats.push({
          itag: preset.itag,
          quality: preset.quality,
          height: preset.height,
          ext: "mp4",
          hasVideo: true,
          hasAudio: true,
          size: calculateFormatSizeMb({ height: preset.height, hasVideo: true, hasAudio: true }, durationSeconds),
          downloadUrl: `/api/download-direct?videoId=${videoId}&format=${preset.height}&title=${encodeURIComponent(title)}&ext=mp4`,
          fps: preset.fps
        });
      }
    }
    combinedFormats.sort((a, b) => (b.height || 0) - (a.height || 0));
    if (audioFormats.length === 0) {
      audioFormats.push(
        {
          itag: 320,
          quality: "320 kbps (MP3 \u0639\u0627\u0644\u064A \u0627\u0644\u0646\u0642\u0627\u0648\u0629)",
          bitrate: 320,
          ext: "mp3",
          container: "mp3",
          hasVideo: false,
          hasAudio: true,
          size: calculateFormatSizeMb({ bitrate: 320, hasVideo: false, hasAudio: true, ext: "mp3" }, durationSeconds),
          downloadUrl: `/api/download-direct?videoId=${videoId}&format=mp3&title=${encodeURIComponent(title)}&ext=mp3`
        },
        {
          itag: 192,
          quality: "192 kbps (MP3 \u0642\u064A\u0627\u0633\u064A)",
          bitrate: 192,
          ext: "mp3",
          container: "mp3",
          hasVideo: false,
          hasAudio: true,
          size: calculateFormatSizeMb({ bitrate: 192, hasVideo: false, hasAudio: true, ext: "mp3" }, durationSeconds),
          downloadUrl: `/api/download-direct?videoId=${videoId}&format=mp3&title=${encodeURIComponent(title)}&ext=mp3`
        }
      );
    }
    const bestThumbnail = `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`;
    const fallbackThumbnail = oembed?.thumbnail_url || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
    setTimeout(() => {
      resolveDirectDownloadStream(videoId, "720").catch(() => {
      });
      resolveDirectDownloadStream(videoId, "360").catch(() => {
      });
      resolveDirectDownloadStream(videoId, "mp3").catch(() => {
      });
    }, 50);
    return res.json({
      id: videoId,
      title,
      description: `\u0641\u064A\u062F\u064A\u0648 ${title} \u0628\u0648\u0627\u0633\u0637\u0629 ${authorName}`,
      author: {
        name: authorName,
        channelUrl: authorUrl,
        subscribers: "",
        avatar: ""
      },
      durationSeconds,
      durationFormatted: formatDuration(durationSeconds),
      views: viewCount,
      viewsFormatted: formatViews(viewCount),
      thumbnail: bestThumbnail,
      fallbackThumbnail,
      embedUrl: `https://www.youtube.com/embed/${videoId}`,
      videoUrl: targetUrl,
      formats: combinedFormats,
      highDefFormats,
      audioFormats
    });
  } catch (error) {
    console.error("Extraction error:", error);
    const msg = error?.message || "";
    return res.status(500).json({
      error: `\u0641\u0634\u0644 \u0627\u0633\u062A\u062E\u0631\u0627\u062C \u0627\u0644\u0631\u0648\u0627\u0628\u0637: ${msg || "\u062E\u0637\u0623 \u0641\u064A \u0645\u0639\u0627\u0644\u062C\u0629 \u0627\u0644\u0631\u0627\u0628\u0637"}`,
      details: msg
    });
  }
});
app.get("/api/resolve-direct", async (req, res) => {
  try {
    const videoId = req.query.videoId;
    const format = req.query.format || "720";
    const title = req.query.title || "youtube_video";
    const ext = req.query.ext || (format === "mp3" ? "mp3" : "mp4");
    if (!videoId) {
      return res.status(400).json({ error: "\u0645\u0639\u0631\u0641 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0645\u0637\u0644\u0648\u0628" });
    }
    const directStreamUrl = await resolveDirectDownloadStream(videoId, format);
    if (directStreamUrl) {
      const proxyDownloadUrl = `/api/stream-proxy?url=${encodeURIComponent(directStreamUrl)}&title=${encodeURIComponent(title)}&ext=${ext}`;
      return res.json({
        success: true,
        directUrl: proxyDownloadUrl,
        downloadUrl: proxyDownloadUrl,
        rawUrl: directStreamUrl
      });
    }
    const fallbackDownloadUrl = `/api/download-direct?videoId=${encodeURIComponent(videoId)}&format=${encodeURIComponent(format)}&title=${encodeURIComponent(title)}&ext=${encodeURIComponent(ext)}`;
    return res.json({
      success: true,
      directUrl: fallbackDownloadUrl,
      downloadUrl: fallbackDownloadUrl
    });
  } catch (error) {
    const fallbackDownloadUrl = `/api/download-direct?videoId=${encodeURIComponent(req.query.videoId || "")}&format=${encodeURIComponent(req.query.format || "720")}&title=${encodeURIComponent(req.query.title || "video")}&ext=${encodeURIComponent(req.query.ext || "mp4")}`;
    return res.json({
      success: true,
      directUrl: fallbackDownloadUrl,
      downloadUrl: fallbackDownloadUrl
    });
  }
});
app.get("/api/download-direct", async (req, res) => {
  try {
    const videoId = req.query.videoId;
    const format = req.query.format || "720";
    const title = req.query.title || "youtube_video";
    const ext = req.query.ext || (format === "mp3" ? "mp3" : "mp4");
    if (!videoId) {
      return res.status(400).send("\u0645\u0639\u0631\u0641 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0645\u0637\u0644\u0648\u0628");
    }
    const safeTitle = sanitizeFilename(title);
    const filename = `${safeTitle}.${ext}`;
    const directStreamUrl = await resolveDirectDownloadStream(videoId, format);
    if (directStreamUrl) {
      const safeAscii = filename.replace(/[^\x20-\x7E]/g, "_") || `download.${ext}`;
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Expose-Headers", "Content-Length, Content-Disposition, Content-Type");
      res.setHeader("Content-Disposition", `attachment; filename="${safeAscii}"; filename*=UTF-8''${encodeURIComponent(filename)}`);
      if (ext === "mp3" && !directStreamUrl.includes("savenow.to") && !directStreamUrl.includes("lbserver.xyz")) {
        res.setHeader("Content-Type", "audio/mpeg");
        const ff = (0, import_child_process.spawn)("ffmpeg", ["-i", directStreamUrl, "-vn", "-acodec", "libmp3lame", "-ab", "192k", "-f", "mp3", "pipe:1"]);
        ff.stdout.pipe(res);
        ff.on("error", () => {
          if (!res.headersSent) res.status(500).end();
          else res.end();
        });
        req.on("close", () => {
          try {
            ff.kill("SIGKILL");
          } catch {
          }
        });
        return;
      }
      const mediaRes = await fetch(directStreamUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
      });
      if (mediaRes.ok && mediaRes.body) {
        res.setHeader("Content-Type", ext === "mp3" ? "audio/mpeg" : "video/mp4");
        if (mediaRes.headers.get("content-length")) {
          res.setHeader("Content-Length", mediaRes.headers.get("content-length"));
        }
        const reader = mediaRes.body.getReader();
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          const ok = res.write(value);
          if (!ok) {
            await new Promise((resolve) => res.once("drain", resolve));
          }
        }
        return res.end();
      }
    }
    res.status(500).send("\u062A\u0639\u0630\u0631 \u0628\u062F\u0621 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0644\u0647\u0630\u0627 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u062D\u0627\u0644\u064A\u0627\u064B.");
  } catch (error) {
    console.error("Direct download error:", error);
    if (!res.headersSent) {
      res.status(500).send(`\u062E\u0637\u0623 \u0623\u062B\u0646\u0627\u0621 \u0627\u0644\u062A\u062D\u0645\u064A\u0644: ${error?.message || "\u063A\u064A\u0631 \u0645\u062A\u0648\u0642\u0639"}`);
    }
  }
});
app.get("/api/stream-proxy", async (req, res) => {
  try {
    const rawMediaUrl = req.query.url;
    const title = req.query.title || "youtube_video";
    const ext = req.query.ext || "mp4";
    if (!rawMediaUrl) {
      return res.status(400).send("\u0631\u0627\u0628\u0637 \u0627\u0644\u0648\u0633\u0627\u0626\u0637 \u063A\u064A\u0631 \u0645\u0648\u062C\u0648\u062F");
    }
    const safeTitle = sanitizeFilename(title);
    const filename = `${safeTitle}.${ext}`;
    const safeAscii = filename.replace(/[^\x20-\x7E]/g, "_") || `download.${ext}`;
    if (ext === "mp3" && !rawMediaUrl.includes("savenow.to") && !rawMediaUrl.includes("lbserver.xyz")) {
      res.setHeader("Access-Control-Allow-Origin", "*");
      res.setHeader("Access-Control-Expose-Headers", "Content-Length, Content-Disposition, Content-Type");
      res.setHeader("Content-Disposition", `attachment; filename="${safeAscii}"; filename*=UTF-8''${encodeURIComponent(filename)}`);
      res.setHeader("Content-Type", "audio/mpeg");
      const ff = (0, import_child_process.spawn)("ffmpeg", ["-i", rawMediaUrl, "-vn", "-acodec", "libmp3lame", "-ab", "192k", "-f", "mp3", "pipe:1"]);
      ff.stdout.pipe(res);
      ff.on("error", () => {
        if (!res.headersSent) res.status(500).end();
        else res.end();
      });
      req.on("close", () => {
        try {
          ff.kill("SIGKILL");
        } catch {
        }
      });
      return;
    }
    const headers = {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
    };
    if (req.headers.range && !rawMediaUrl.includes("piped.private.coffee") && !rawMediaUrl.includes("savenow.to") && !rawMediaUrl.includes("lbserver.xyz")) {
      headers["Range"] = req.headers.range;
    }
    const mediaRes = await fetch(rawMediaUrl, {
      headers
    });
    if (!mediaRes.ok && mediaRes.status !== 206) {
      return res.status(502).send("\u062A\u0639\u0630\u0631 \u062C\u0644\u0628 \u062F\u0641\u0642 \u0627\u0644\u0648\u0633\u0627\u0626\u0637 \u0645\u0646 \u0627\u0644\u062E\u0627\u062F\u0645 \u0627\u0644\u0623\u0635\u0644\u064A");
    }
    res.status(mediaRes.status);
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Expose-Headers", "Content-Length, Content-Disposition, Content-Type");
    res.setHeader("Content-Disposition", `attachment; filename="${safeAscii}"; filename*=UTF-8''${encodeURIComponent(filename)}`);
    if (mediaRes.headers.get("content-type")) {
      res.setHeader("Content-Type", mediaRes.headers.get("content-type"));
    } else {
      res.setHeader("Content-Type", ext === "mp4" ? "video/mp4" : ext === "m4a" ? "audio/mp4" : "application/octet-stream");
    }
    if (mediaRes.headers.get("content-length")) {
      res.setHeader("Content-Length", mediaRes.headers.get("content-length"));
    }
    if (mediaRes.headers.get("accept-ranges")) {
      res.setHeader("Accept-Ranges", mediaRes.headers.get("accept-ranges"));
    }
    if (mediaRes.headers.get("content-range")) {
      res.setHeader("Content-Range", mediaRes.headers.get("content-range"));
    }
    if (!mediaRes.body) {
      return res.end();
    }
    const reader = mediaRes.body.getReader();
    const pump = async () => {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) {
            res.end();
            break;
          }
          const ok = res.write(value);
          if (!ok) {
            await new Promise((resolve) => res.once("drain", resolve));
          }
        }
      } catch (err) {
        console.error("Stream piping error:", err);
        res.end();
      }
    };
    pump();
  } catch (error) {
    console.error("Stream proxy error:", error);
    if (!res.headersSent) {
      res.status(500).send(`\u0641\u0634\u0644 \u062A\u062F\u0641\u0642 \u0627\u0644\u0648\u0633\u0627\u0626\u0637: ${error?.message || "\u062E\u0637\u0623"}`);
    }
  }
});
async function startServer() {
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`\u2728 \u0633\u062D\u0631 \u0627\u0644\u062A\u062D\u0645\u064A\u0644 \u064A\u0639\u0645\u0644 \u0627\u0644\u0622\u0646 \u0639\u0644\u0649 \u0627\u0644\u0645\u0646\u0641\u0630: http://0.0.0.0:${PORT}`);
  });
  if (process.env.NODE_ENV !== "production" && import_fs3.default.existsSync(import_path3.default.join(process.cwd(), "dist", "index.html")) === false) {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else if (process.env.NODE_ENV !== "production") {
    const vite = await (0, import_vite.createServer)({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = import_path3.default.join(process.cwd(), "dist");
    app.use(import_express.default.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(import_path3.default.join(distPath, "index.html"));
    });
  }
}
if (!process.env.VERCEL) {
  startServer();
}
var server_default = app;
//# sourceMappingURL=server.cjs.map
